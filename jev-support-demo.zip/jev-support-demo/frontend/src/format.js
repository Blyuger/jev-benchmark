export const MODEL_COLOR = {
  jev: 'var(--jev)', haiku: 'var(--haiku)', sonnet: 'var(--sonnet)', luna: 'var(--luna)', sol: 'var(--sol)',
}
export const seconds = (x) => (x == null ? '–' : `${(x / 1000).toFixed(1)} s`)

export const FIELDS = ['level', 'category', 'priority', 'sentiment', 'risk']
export const FIELD_NAMES = {
  level: 'Level', category: 'Category', priority: 'Priority', sentiment: 'Sentiment', risk: 'Risk',
}

export const pct = (x, digits = 0) => (x == null ? '–' : `${(x * 100).toFixed(digits)}%`)
export const ms = (x) => {
  if (x == null) return '–'
  return x >= 1000 ? `${(x / 1000).toFixed(2)} s` : `${Math.round(x)} ms`
}
export const usd = (x) => {
  if (x == null) return '–'
  if (x === 0) return '$0'
  if (x < 0.01) return `$${+x.toPrecision(2)}`
  if (x < 100) return `$${x.toFixed(2)}`
  return `$${Math.round(x).toLocaleString('en-US')}`
}
export const num = (x, d = 3) => (x == null ? '–' : x.toFixed(d))
export const human = (label) => (label == null ? 'invalid' : String(label).replace(/_/g, ' '))
