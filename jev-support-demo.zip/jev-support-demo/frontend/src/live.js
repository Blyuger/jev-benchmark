import { useEffect, useReducer, useRef } from 'react'

const initial = {
  connected: false,
  config: null,
  status: 'idle',
  mode: 'pipeline',
  speed: 1,
  threshold: 0.75,
  position: 0,
  total: 0,
  message: '',
  current: null,
  feed: [],
  metrics: {},
  comparison: null,
  lanes: {},
  lastTicketId: null,
  error: '',
}

function stamp(lanes) {
  const now = Date.now()
  return Object.fromEntries(Object.entries(lanes).map(([k, l]) => [k, { ...l, received_at: now }]))
}

/** Current run time for a lane, ticking locally between server events. */
export function laneNow(lane) {
  if (!lane) return 0
  if (lane.finished_ms != null) return lane.finished_ms
  return lane.elapsed_ms + (lane.running ? Date.now() - lane.received_at : 0)
}

function reducer(state, action) {
  switch (action.type) {
    case 'connected':
      return { ...state, connected: action.value }
    case 'error':
      return { ...state, error: action.value }
    case 'state': {
      const d = action.data
      return {
        ...state, config: d.config, status: d.status, mode: d.mode, speed: d.speed,
        threshold: d.threshold, position: d.position, total: d.total, message: d.message,
        current: d.current, feed: d.feed || [], metrics: d.metrics || {}, comparison: d.comparison,
        lanes: stamp(d.lanes || {}), error: '',
      }
    }
    case 'status': {
      // Re-base every lane clock on the server's elapsed time (pause/resume changes it)
      const now = Date.now()
      const lanes = Object.fromEntries(Object.entries(state.lanes).map(([k, l]) => [
        k, { ...l, elapsed_ms: action.data.elapsed_ms ?? l.elapsed_ms, received_at: now,
             running: action.data.status === 'running' },
      ]))
      return { ...state, ...action.data, lanes }
    }
    case 'lane':
      return { ...state, lanes: { ...state.lanes, [action.data.key]: { ...action.data, received_at: Date.now() } } }
    case 'ticket':
      return {
        ...state, position: action.data.position, total: action.data.total,
        current: { ticket: action.data.ticket, results: {}, started_at: Date.now() / 1000 },
      }
    case 'result': {
      const p = action.data
      const current = state.current && state.current.ticket.id === p.ticket_id
        ? { ...state.current, results: { ...state.current.results, [p.model_key]: p } }
        : state.current
      return { ...state, current, feed: [...state.feed, p], lastTicketId: p.ticket_id }
    }
    case 'metrics':
      return { ...state, metrics: { ...state.metrics, [action.data.key]: action.data } }
    case 'comparison':
      return { ...state, comparison: action.data }
    default:
      return state
  }
}

/** Live connection to the backend: WebSocket events folded into one state object. */
export function useLive() {
  const [state, dispatch] = useReducer(reducer, initial)
  const retry = useRef(0)

  useEffect(() => {
    let ws
    let closed = false
    let timer
    const connect = () => {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws'
      ws = new WebSocket(`${proto}://${location.host}/ws`)
      ws.onopen = () => { retry.current = 0; dispatch({ type: 'connected', value: true }) }
      ws.onmessage = (ev) => {
        const msg = JSON.parse(ev.data)
        dispatch({ type: msg.type, data: msg.data })
      }
      ws.onclose = () => {
        dispatch({ type: 'connected', value: false })
        if (!closed) timer = setTimeout(connect, Math.min(5000, 500 * 2 ** retry.current++))
      }
    }
    connect()
    return () => { closed = true; clearTimeout(timer); ws && ws.close() }
  }, [])

  const post = async (path, body) => {
    const res = await fetch(`/api/${path}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    })
    if (!res.ok) {
      const detail = (await res.json().catch(() => ({}))).detail || res.statusText
      dispatch({ type: 'error', value: String(detail) })
    } else {
      dispatch({ type: 'error', value: '' })
    }
  }

  const actions = {
    run: (opts) => post('run', opts),
    pause: () => post('pause'),
    resume: () => post('resume'),
    stop: () => post('stop'),
    speed: (speed) => post('speed', { speed }),
    threshold: (value) => post('threshold', { value }),
  }
  return [state, actions]
}
