import { FIELDS, FIELD_NAMES, human } from './format.js'

/** Correctness mark against the answer key. Status color is always paired with an icon + word. */
export function Mark({ correct, compact = false }) {
  if (correct) return <span className="mark ok" title="Matches the answer key">✓{compact ? '' : ' Right'}</span>
  return <span className="mark no" title="Does not match the answer key">✗{compact ? '' : ' Wrong'}</span>
}

export function OutcomeMark({ outcome }) {
  if (outcome === 'correct') return <span className="mark ok">✓ Right queue</span>
  if (outcome === 'safe') return <span className="mark alt">↑ More senior than needed</span>
  return <span className="mark no">! Too junior</span>
}

export function Tile({ label, value, note }) {
  return (
    <div className="tile">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {note && <div className="note">{note}</div>}
    </div>
  )
}

const SPEEDS = [[1, '1×'], [5, '5×'], [20, '20×'], [0, 'Max']]
const LIMITS = [[null, 'All'], [20, '20'], [40, '40']]

export function Controls({ live, actions, mode, limit, setLimit }) {
  const running = ['running', 'warming_up', 'paused'].includes(live.status)
  const otherMode = running && live.mode !== mode
  const label = mode === 'pipeline' ? 'Run pipeline' : 'Run comparison'
  return (
    <div className="controls">
      <div className="seg" role="group" aria-label="Tickets to run">
        {LIMITS.map(([v, l]) => (
          <button key={l} aria-pressed={limit === v} onClick={() => setLimit(v)} disabled={running}>{l}</button>
        ))}
      </div>
      <div className="seg" role="group" aria-label="Replay speed">
        {SPEEDS.map(([v, l]) => (
          <button key={l} aria-pressed={live.speed === v} onClick={() => actions.speed(v)}>{l}</button>
        ))}
      </div>
      {!running && (
        <button className="btn primary" onClick={() => actions.run({ mode, speed: live.speed, shuffle: true, limit })}>
          {label}
        </button>
      )}
      {running && live.status === 'paused' && <button className="btn" onClick={actions.resume}>Resume</button>}
      {running && live.status !== 'paused' && <button className="btn" onClick={actions.pause}>Pause</button>}
      {running && <button className="btn" onClick={actions.stop}>Stop</button>}
      {otherMode && <span className="pill">The {live.mode} run is in progress</span>}
    </div>
  )
}

const STATUS_TEXT = {
  idle: 'Ready', warming_up: 'Warming up', running: 'Running', paused: 'Paused',
  finished: 'Finished', stopped: 'Stopped', error: 'Error',
}

export function StatusLine({ live }) {
  const pctDone = live.total ? (live.position / live.total) * 100 : 0
  return (
    <div className="status-line" aria-live="polite">
      <span className="pill">
        <span className="dot" style={{ background: live.connected ? 'var(--good)' : 'var(--bad)' }} />
        {live.connected ? STATUS_TEXT[live.status] || live.status : 'Disconnected from backend'}
      </span>
      {live.total > 0 && live.mode !== 'comparison' && (
        <>
          <span>Ticket {live.position} of {live.total}</span>
          <div className="progress" aria-hidden="true"><div style={{ width: `${pctDone}%` }} /></div>
        </>
      )}
      {live.message && <span>{live.message}</span>}
    </div>
  )
}

export function TicketCard({ ticket, showGold = true }) {
  if (!ticket) return <div className="empty">Start a run to see tickets arrive here.</div>
  return (
    <div>
      <div className="ticket-meta">
        <span>{ticket.id}</span>
        <span>{ticket.channel}</span>
        <span>{human(ticket.plan)} plan</span>
        {ticket.difficulty === 'ambiguous' && <span>borderline case</span>}
      </div>
      <p className="ticket-subject">{ticket.subject}</p>
      <p className="ticket-body">{ticket.message}</p>
      {showGold && (
        <div className="gold-strip">
          <span>Answer key</span>
          {FIELDS.map((f) => (
            <span className="tag" key={f} title={FIELD_NAMES[f]}>{human(ticket.gold[f])}</span>
          ))}
        </div>
      )}
    </div>
  )
}

function RateCell({ bucket, color }) {
  if (!bucket || !bucket.total) return <td>–</td>
  return (
    <td style={{ '--c': color }}>
      <div className="cell-rate">{bucket.rate == null ? '–' : `${Math.round(bucket.rate * 100)}%`}</div>
      <div className="cell-count">{bucket.correct} of {bucket.total}</div>
      <div className="cell-bar"><div style={{ width: `${(bucket.rate || 0) * 100}%` }} /></div>
    </td>
  )
}

/**
 * Accuracy on the level question, split by how hard the ticket is.
 * Shows counts ("19 of 21") and rates (90%) so the audience can read both.
 */
export function DifficultyTables({ metrics, keys, models, colors }) {
  const present = keys.filter((k) => metrics[k])
  if (!present.length) return <div className="empty">No data yet.</div>
  const name = (k) => (
    <span className="model-cell"><span className="dot" style={{ background: colors[k] }} />{models[k] || k}</span>
  )
  return (
    <div className="grid cols-2">
      <div style={{ overflowX: 'auto' }}>
        <h3 style={{ fontSize: 14, margin: '0 0 6px' }}>Clear vs borderline tickets</h3>
        <table className="table diff">
          <thead>
            <tr>
              <th scope="col">Model</th>
              <th scope="col">Clear tickets</th>
              <th scope="col">Borderline tickets</th>
            </tr>
          </thead>
          <tbody>
            {present.map((k) => {
              const d = metrics[k].by_difficulty
              return (
                <tr key={k}>
                  <td>{name(k)}</td>
                  <RateCell bucket={{ ...d.clear.level, total: d.clear.total }} color={colors[k]} />
                  <RateCell bucket={{ ...d.ambiguous.level, total: d.ambiguous.total }} color={colors[k]} />
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <h3 style={{ fontSize: 14, margin: '0 0 6px' }}>By support level in the answer key</h3>
        <table className="table diff">
          <thead>
            <tr>
              <th scope="col">Model</th>
              {['N0', 'N1', 'N2', 'N3'].map((l) => <th scope="col" key={l}>{l}</th>)}
            </tr>
          </thead>
          <tbody>
            {present.map((k) => (
              <tr key={k}>
                <td>{name(k)}</td>
                {['N0', 'N1', 'N2', 'N3'].map((l) => {
                  const b = metrics[k].by_level[l]
                  return <RateCell key={l} bucket={b && { ...b.level, total: b.total }} color={colors[k]} />
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function SplitCell({ group }) {
  if (!group || !group.total) return <td><span className="cell-count">None</span></td>
  return (
    <td>
      <div className="cell-rate">{Math.round(group.accuracy * 100)}% right</div>
      <div className="cell-count">{group.right} of {group.total} tickets</div>
      <div className="split-bar" role="img" aria-label={`${group.right} right, ${group.wrong} wrong`}>
        {group.right > 0 && <div className="seg-right" style={{ flex: group.right }} />}
        {group.wrong > 0 && <div className="seg-wrong" style={{ flex: group.wrong }} />}
      </div>
    </td>
  )
}

/**
 * "When the model says it's sure, is it right?"
 * Level answers split at the routing threshold. Sure answers are the ones the system automates;
 * a wrong answer the model was sure about (a confident mistake) is the costly kind.
 */
export function ConfidenceSplit({ metrics, keys, models, colors }) {
  const present = keys.filter((k) => metrics[k])
  if (!present.length) return <div className="empty">No data yet.</div>
  const t = metrics[present[0]].confidence_split.threshold
  const tPct = `${Math.round(t * 100)}%`
  return (
    <div style={{ overflowX: 'auto' }}>
      <table className="table diff split">
        <thead>
          <tr>
            <th scope="col">Model</th>
            <th scope="col">Said it was sure<span className="hint">Confidence {tPct} or more, so the system acts on it</span></th>
            <th scope="col">Said it was unsure<span className="hint">Below {tPct}, so the ticket is escalated</span></th>
            <th scope="col">Confident mistakes<span className="hint">Wrong while sure. Fewer is better</span></th>
          </tr>
        </thead>
        <tbody>
          {present.map((k) => {
            const c = metrics[k].confidence_split
            return (
              <tr key={k}>
                <td>
                  <span className="model-cell"><span className="dot" style={{ background: colors[k] }} />{models[k] || k}</span>
                  <span className="hint">{metrics[k].confidence_source === 'calibrated' ? 'Calibrated probability' : 'Confidence written in its answer'}</span>
                </td>
                <SplitCell group={c.sure} />
                <SplitCell group={c.unsure} />
                <td>
                  <div className={`cell-rate ${c.sure.wrong > 0 ? 'bad-ink' : ''}`}>{c.sure.wrong > 0 ? `! ${c.sure.wrong}` : '0'}</div>
                  <div className="cell-count">of {metrics[k].processed} tickets</div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <div className="legend">
        <span><i className="key" style={{ background: 'var(--good)', borderColor: 'var(--good)' }} />✓ Right</span>
        <span><i className="key" style={{ background: 'var(--bad)', borderColor: 'var(--bad)' }} />✗ Wrong</span>
      </div>
    </div>
  )
}
