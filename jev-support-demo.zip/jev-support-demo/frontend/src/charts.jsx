import { useMemo, useState } from 'react'

/* Small hand-built SVG charts: thin marks, hairline grid, hover tooltips, one axis each. */

const PAD = { l: 44, r: 12, t: 10, b: 28 }

function Tooltip({ x, y, w, h, children }) {
  if (x == null) return null
  return (
    <div className="tooltip" style={{ left: `${(x / w) * 100}%`, top: `${(y / h) * 100}%` }}>
      {children}
    </div>
  )
}

export function SeriesLegend({ series }) {
  if (series.length < 2) return null
  return (
    <div className="series-legend">
      {series.map((s) => (
        <span key={s.key}><i className="swatch-line" style={{ background: s.color }} />{s.name}</span>
      ))}
    </div>
  )
}

function niceLogTicks(min, max) {
  const out = []
  const decades = Math.log10(max) - Math.log10(min)
  const mults = decades <= 2 ? [1, 2, 5] : [1]
  for (let p = Math.floor(Math.log10(min)); p <= Math.ceil(Math.log10(max)); p++) {
    for (const m of mults) {
      const v = m * 10 ** p
      if (v >= min * 0.999 && v <= max * 1.001) out.push(v)
    }
  }
  return out
}

function niceTicks(max, count = 4) {
  if (max <= 0) return [0]
  const raw = max / count
  const mag = 10 ** Math.floor(Math.log10(raw))
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw)
  const ticks = []
  for (let v = 0; v <= max + step * 0.001; v += step) ticks.push(+v.toFixed(10))
  return ticks
}

/** Multi-series line chart over ticket index. series: [{key, name, color, points: [{x, y, label}]}] */
export function LineChart({ series, width = 600, height = 220, yLog = false, yFormat = (v) => v, xTitle = 'Ticket #', yMin, yMax }) {
  const W = width
  const H = height
  const [hover, setHover] = useState(null)
  const all = series.flatMap((s) => s.points)
  const { xMax, lo, hi, ticks } = useMemo(() => {
    const xMax = Math.max(10, ...all.map((p) => p.x))
    const ys = all.map((p) => p.y).filter((v) => v != null && (!yLog || v > 0))
    let lo = yMin ?? (yLog ? Math.min(...ys) : 0)
    let hi = yMax ?? Math.max(...ys)
    if (!ys.length) { lo = yLog ? 10 : 0; hi = yLog ? 1000 : 1 }
    if (yLog) {
      lo = 10 ** Math.floor(Math.log10(lo || 1))
      hi = 10 ** Math.ceil(Math.log10(hi || 10))
      if (hi <= lo) hi = lo * 10
      return { xMax, lo, hi, ticks: niceLogTicks(lo, hi) }
    }
    const t = niceTicks(hi || 1)
    return { xMax, lo, hi: t[t.length - 1], ticks: t }
  }, [all, yLog, yMin, yMax])

  const px = (x) => PAD.l + ((x - 1) / Math.max(1, xMax - 1)) * (W - PAD.l - PAD.r)
  const py = (y) => {
    const f = yLog ? (Math.log10(y) - Math.log10(lo)) / (Math.log10(hi) - Math.log10(lo)) : (y - lo) / (hi - lo || 1)
    return H - PAD.b - f * (H - PAD.t - PAD.b)
  }
  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect()
    const x = ((e.clientX - r.left) / r.width) * W
    const idx = Math.round(1 + ((x - PAD.l) / (W - PAD.l - PAD.r)) * (xMax - 1))
    setHover(idx >= 1 && idx <= xMax ? idx : null)
  }
  const hoverRows = hover == null ? [] : series
    .map((s) => ({ s, p: s.points.find((p) => p.x === hover) }))
    .filter((r) => r.p)

  return (
    <div className="chart-wrap">
      <SeriesLegend series={series} />
      <div className="chart-wrap">
      <svg className="chart" viewBox={`0 0 ${W} ${H}`} onMouseMove={onMove} onMouseLeave={() => setHover(null)}
        role="img" aria-label={`Line chart with ${series.length} series`}>
        {ticks.map((t) => (
          <g key={t}>
            <line className="grid-line" x1={PAD.l} x2={W - PAD.r} y1={py(t)} y2={py(t)} />
            <text x={PAD.l - 6} y={py(t) + 4} textAnchor="end">{yFormat(t)}</text>
          </g>
        ))}
        <line className="axis-line" x1={PAD.l} x2={W - PAD.r} y1={H - PAD.b} y2={H - PAD.b} />
        <text x={PAD.l} y={H - 8}>1</text>
        <text x={W - PAD.r} y={H - 8} textAnchor="end">{xMax}</text>
        <text x={(W + PAD.l) / 2} y={H - 8} textAnchor="middle">{xTitle}</text>
        {series.map((s) => {
          const pts = s.points.filter((p) => p.y != null && (!yLog || p.y > 0))
          if (!pts.length) return null
          const d = pts.map((p, i) => `${i ? 'L' : 'M'}${px(p.x).toFixed(1)},${py(p.y).toFixed(1)}`).join('')
          const last = pts[pts.length - 1]
          return (
            <g key={s.key}>
              <path d={d} fill="none" stroke={s.color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
              <circle cx={px(last.x)} cy={py(last.y)} r="4" fill={s.color} stroke="var(--panel)" strokeWidth="2" />
            </g>
          )
        })}
        {hover != null && (
          <g>
            <line x1={px(hover)} x2={px(hover)} y1={PAD.t} y2={H - PAD.b} stroke="var(--ink-3)" strokeWidth="1" />
            {hoverRows.map(({ s, p }) => (p.y != null && (!yLog || p.y > 0)) && (
              <circle key={s.key} cx={px(p.x)} cy={py(p.y)} r="4" fill={s.color} stroke="var(--panel)" strokeWidth="2" />
            ))}
          </g>
        )}
      </svg>
      {hoverRows.length > 0 && (
        <Tooltip x={px(hover)} y={Math.min(...hoverRows.map(({ p }) => py(p.y ?? lo)))} w={W} h={H}>
          <div><b>#{hover}</b> {hoverRows[0].p.label}</div>
          {hoverRows.map(({ s, p }) => <div key={s.key}>{s.name}: <b>{yFormat(p.y)}</b></div>)}
        </Tooltip>
      )}
      </div>
    </div>
  )
}

/** Grouped columns. groups: [label], series: [{key, name, color, values: [0..1]}] */
export function GroupedBars({ groups, series, width = 600, height = 220, format = (v) => v, max = 1 }) {
  const W = width
  const H = height
  const [hover, setHover] = useState(null)
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => f * max)
  const band = (W - PAD.l - PAD.r) / groups.length
  const barW = Math.min(24, (band * 0.7) / series.length - 2)
  const py = (v) => H - PAD.b - (v / max) * (H - PAD.t - PAD.b)
  return (
    <div className="chart-wrap">
      <SeriesLegend series={series} />
      <div className="chart-wrap">
      <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Grouped bar chart">
        {ticks.map((t) => (
          <g key={t}>
            <line className="grid-line" x1={PAD.l} x2={W - PAD.r} y1={py(t)} y2={py(t)} />
            <text x={PAD.l - 6} y={py(t) + 4} textAnchor="end">{format(t)}</text>
          </g>
        ))}
        {groups.map((g, gi) => {
          const groupW = series.length * (barW + 2) - 2
          const x0 = PAD.l + gi * band + (band - groupW) / 2
          return (
            <g key={g}>
              <text x={PAD.l + gi * band + band / 2} y={H - 8} textAnchor="middle">{g}</text>
              {series.map((s, si) => {
                const v = s.values[gi]
                if (v == null) return null
                const x = x0 + si * (barW + 2)
                const y = py(v)
                const h = Math.max(0, H - PAD.b - y)
                const r = Math.min(4, h)
                const d = `M${x},${H - PAD.b}V${y + r}Q${x},${y} ${x + r},${y}H${x + barW - r}Q${x + barW},${y} ${x + barW},${y + r}V${H - PAD.b}Z`
                return (
                  <g key={s.key} onMouseEnter={() => setHover({ x: x + barW / 2, y, s, g, v })} onMouseLeave={() => setHover(null)}>
                    <rect x={x - 3} y={PAD.t} width={barW + 6} height={H - PAD.t - PAD.b} fill="transparent" />
                    <path d={d} fill={s.color} />
                  </g>
                )
              })}
            </g>
          )
        })}
        <line className="axis-line" x1={PAD.l} x2={W - PAD.r} y1={H - PAD.b} y2={H - PAD.b} />
      </svg>
      {hover && (
        <Tooltip x={hover.x} y={hover.y} w={W} h={H}>
          <b>{hover.s.name}</b>, {hover.g}: <b>{format(hover.v)}</b>
        </Tooltip>
      )}
      </div>
    </div>
  )
}

/** Confusion matrix on the level question (rows = gold, columns = predicted). */
export function ConfusionMatrix({ labels, matrix }) {
  const max = Math.max(1, ...matrix.flat())
  const shade = (v) => (v === 0 ? 'var(--seq-0)' : `var(--seq-${Math.min(5, 1 + Math.floor((v / max) * 4.999))})`)
  const inkFor = (v) => (v / max > 0.55 ? '#fff' : 'var(--ink)')
  const hasInvalid = matrix.some((row) => row[labels.length] > 0)
  return (
    <table className="matrix">
      <thead>
        <tr>
          <th aria-label="Gold level" />
          {labels.map((l) => <th key={l} scope="col">{l}</th>)}
          {hasInvalid && <th scope="col">invalid</th>}
        </tr>
      </thead>
      <tbody>
        {labels.map((g, i) => (
          <tr key={g}>
            <th scope="row">{g}</th>
            {matrix[i].slice(0, hasInvalid ? undefined : labels.length).map((v, j) => (
              <td key={j} className={i === j ? 'diag' : ''} style={{ background: shade(v), color: inkFor(v) }}
                title={`Gold ${g}, predicted ${labels[j] || 'invalid'}: ${v}`}>{v}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  )
}

/** Coverage vs accuracy as the confidence threshold moves (level question). */
export function CoverageChart({ coverage, threshold, color, height = 220 }) {
  const W = 600
  const H = height
  const [hover, setHover] = useState(null)
  const px = (t) => PAD.l + t * (W - PAD.l - PAD.r)
  const py = (v) => H - PAD.b - v * (H - PAD.t - PAD.b)
  const line = (key) => coverage.filter((c) => c[key] != null)
    .map((c, i) => `${i ? 'L' : 'M'}${px(c.threshold).toFixed(1)},${py(c[key]).toFixed(1)}`).join('')
  const series = [
    { key: 'accuracy', name: 'Accuracy of automated decisions', color },
    { key: 'coverage', name: 'Share of tickets automated', color: 'var(--ink-3)' },
  ]
  const at = coverage.reduce((best, c) => (Math.abs(c.threshold - threshold) < Math.abs(best.threshold - threshold) ? c : best), coverage[0] || { threshold: 0 })
  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect()
    const t = ((e.clientX - r.left) / r.width * W - PAD.l) / (W - PAD.l - PAD.r)
    const c = coverage.reduce((b, x) => (Math.abs(x.threshold - t) < Math.abs(b.threshold - t) ? x : b), coverage[0])
    setHover(t >= -0.02 && t <= 1.02 ? c : null)
  }
  return (
    <div className="chart-wrap">
      <SeriesLegend series={series} />
      <div className="chart-wrap">
        <svg className="chart" viewBox={`0 0 ${W} ${H}`} onMouseMove={onMove} onMouseLeave={() => setHover(null)}
          role="img" aria-label="Coverage and accuracy by confidence threshold">
          {[0, 0.25, 0.5, 0.75, 1].map((t) => (
            <g key={t}>
              <line className="grid-line" x1={PAD.l} x2={W - PAD.r} y1={py(t)} y2={py(t)} />
              <text x={PAD.l - 6} y={py(t) + 4} textAnchor="end">{t * 100}%</text>
              <text x={px(t)} y={H - 8} textAnchor="middle">{t.toFixed(2)}</text>
            </g>
          ))}
          <line className="axis-line" x1={PAD.l} x2={W - PAD.r} y1={H - PAD.b} y2={H - PAD.b} />
          <line x1={px(threshold)} x2={px(threshold)} y1={PAD.t} y2={H - PAD.b} stroke="var(--ink)" strokeWidth="1" />
          {series.map((s) => <path key={s.key} d={line(s.key)} fill="none" stroke={s.color} strokeWidth="2" strokeLinejoin="round" />)}
          {series.map((s) => at[s.key] != null && (
            <circle key={s.key} cx={px(at.threshold)} cy={py(at[s.key])} r="4" fill={s.color} stroke="var(--panel)" strokeWidth="2" />
          ))}
        </svg>
        {hover && (
          <Tooltip x={px(hover.threshold)} y={py(Math.max(hover.accuracy ?? 0, hover.coverage ?? 0))} w={W} h={H}>
            <div>Threshold <b>{hover.threshold.toFixed(2)}</b></div>
            <div>Automated: <b>{hover.coverage == null ? '–' : Math.round(hover.coverage * 100) + '%'}</b></div>
            <div>Accuracy: <b>{hover.accuracy == null ? '–' : Math.round(hover.accuracy * 100) + '%'}</b></div>
          </Tooltip>
        )}
      </div>
    </div>
  )
}
