import { useEffect, useState } from 'react'
import { GroupedBars, LineChart } from './charts.jsx'
import { ConfidenceSplit, DifficultyTables, Mark, Tile } from './components.jsx'
import { FIELDS, FIELD_NAMES, MODEL_COLOR, ms, num, pct, seconds, usd } from './format.js'
import { laneNow } from './live.js'

const ORDINAL = ['', '1st', '2nd', '3rd', '4th', '5th', '6th']

/** Time this model has spent answering so far, including the request still in flight. */
function modelTime(lane) {
  if (!lane) return 0
  const inFlight = lane.state === 'working' && lane.request_started_ms != null
    ? Math.max(0, laneNow(lane) - lane.request_started_ms) : 0
  return lane.busy_ms + inFlight
}

/** Re-render every 100 ms while a run is active, so the clocks tick smoothly. */
function useTicker(active) {
  const [, setT] = useState(0)
  useEffect(() => {
    if (!active) return undefined
    const id = setInterval(() => setT((t) => t + 1), 100)
    return () => clearInterval(id)
  }, [active])
}

/** Compact "race track": one bar per model, filling as it gets through the tickets. */
function RaceTrack({ lanes, keys }) {
  return (
    <div className="track" role="list">
      {keys.map((k) => {
        const l = lanes[k]
        const done = l?.done || 0
        const total = l?.total || 0
        const status = l?.state === 'finished'
          ? `Finished ${ORDINAL[l.rank] || ''}`
          : l?.state === 'waiting' ? 'Starting' : `Ticket ${l?.position || 0} of ${total}`
        return (
          <div className="track-row" role="listitem" key={k} style={{ '--c': MODEL_COLOR[k] }}>
            <span className="track-name"><span className="dot" style={{ background: MODEL_COLOR[k] }} />{l?.name || k}</span>
            <div className="track-bar" aria-label={`${done} of ${total} tickets done`}>
              <div style={{ width: `${total ? (done / total) * 100 : 0}%` }} />
            </div>
            <span className="track-time">{l?.state === 'finished' ? seconds(l.finished_ms) : `${done}/${total}`}</span>
            <span className="track-status">{l?.state === 'finished' ? status : 'Racing'}</span>
          </div>
        )
      })}
    </div>
  )
}

/** One model's own process: its clock, the ticket it is working on, and its latest answers. */
function RaceLane({ lane, color }) {
  if (!lane) return null
  const now = laneNow(lane)
  const working = lane.state === 'working'
  const reqMs = working && lane.request_started_ms != null ? Math.max(0, now - lane.request_started_ms) : null
  const last = lane.recent?.[0]
  const accuracy = lane.done ? lane.correct_level / lane.done : null
  return (
    <div className={`rlane ${lane.state === 'finished' ? 'finished' : ''}`} style={{ '--c': color }}>
      <div className="rlane-head">
        <b>{lane.name}</b>
        <span>{lane.setting_note}</span>
      </div>
      <div>
        <div className="clock" aria-live="off">{seconds(modelTime(lane))}</div>
        <div className="clock-label">Time spent answering</div>
        <div className="clock-label">
          {lane.state === 'finished'
            ? `All ${lane.total} tickets done at ${seconds(lane.finished_ms)}`
            : `Ticket ${lane.position || 0} of ${lane.total}`}
        </div>
      </div>
      {lane.state === 'finished' && <span className="finish">Finished {ORDINAL[lane.rank]}</span>}

      {lane.state !== 'finished' && (
        <div className="now">
          <div className="now-head">
            <span>{lane.ticket ? `Now: ${lane.ticket.id}` : 'Waiting to start'}</span>
          </div>
          {lane.ticket && (
            <>
              <div className="now-subject">{lane.ticket.subject}</div>
              <div className="now-msg">{lane.ticket.message}</div>
            </>
          )}
        </div>
      )}

      <div className="req">
        {working && <><span className="spinner" style={{ '--c': color }} aria-hidden="true" />Answering <b>{seconds(reqMs)}</b></>}
        {!working && last && (
          <>Last answer in <b>{ms(last.latency_ms)}</b>{`, ${last.level ?? 'invalid'}`}
            <Mark correct={last.correct} compact /></>
        )}
      </div>

      {lane.recent?.length > 0 && (
        <ul className="recent" aria-label="Latest answers">
          {lane.recent.map((r) => (
            <li key={r.ticket_id}>
              <span>{r.ticket_id}</span>
              <span>{r.level ?? 'invalid'} <span style={{ color: 'var(--ink-3)' }}>(key {r.gold_level})</span></span>
              <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
                <Mark correct={r.correct} compact />
                <span className="lat">{ms(r.latency_ms)}</span>
              </span>
            </li>
          ))}
        </ul>
      )}

      <div className="rlane-foot">
        <span>Level right: <b>{lane.correct_level} of {lane.done}</b>{accuracy != null && ` (${pct(accuracy)})`}</span>
        <span>Average per ticket: <b>{lane.done ? ms(lane.busy_ms / lane.done) : '–'}</b></span>
      </div>
    </div>
  )
}

// [label, getter(metrics, lane), better ("high" | "low"), formatter, hint]
const ROWS = [
  ['Time to finish all tickets', (m, l) => l?.finished_ms, 'low', seconds, 'Wall clock, each model on its own'],
  ['Level accuracy', (m) => m.accuracy.by_field.level, 'high', pct, 'Support level (N0 to N3) matches the answer key'],
  ['Tickets with every label right', (m) => m.accuracy.all_fields, 'high', pct,
    'Level, category, priority, sentiment and risk all match the answer key'],
  ['Unsafe routings', (m) => m.routing.outcomes.unsafe, 'low', (v) => v, 'Ticket sent to a queue too junior'],
  ['Risky tickets missed', (m) => m.risk_detection.missed, 'low', (v) => v, 'Churn, legal or exposure not flagged'],
  ['Invalid or failed answers', (m) => m.invalid_outputs + m.errors, 'low', (v) => v, 'Label outside the taxonomy, or request error'],
  ['Latency, median', (m) => m.latency.p50, 'low', ms, null],
  ['Latency, p95', (m) => m.latency.p95, 'low', ms, '95% of answers were faster than this'],
  ['Cost so far', (m) => m.cost.total_usd, 'low', usd, null],
  ['Cost per 1,000 tickets', (m) => m.cost.per_1k_tickets_usd, 'low', usd, 'Projected from the run'],
  ['Confident mistakes', (m) => m.confidence_split.sure.wrong, 'low', (v) => v,
    'Wrong level while saying it was sure, so the system acted on it'],
  ['Accuracy when sure', (m) => m.confidence_split.sure.accuracy, 'high', pct,
    'Level answers given at or above the confidence threshold'],
  ['Brier score', (m) => m.calibration.all.brier, 'low', (v) => num(v),
    'How far confidence is from reality. 0 is perfect; confident mistakes cost the most'],
]

function Scoreboard({ metrics, lanes, models, keys }) {
  const present = keys.filter((k) => metrics[k])
  if (!present.length) return <div className="empty">Run the comparison to fill this table.</div>
  return (
    <div style={{ overflowX: 'auto' }}>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Metric</th>
            {present.map((k) => (
              <th scope="col" key={k}>
                <span className="model-cell"><span className="dot" style={{ background: MODEL_COLOR[k] }} />{models[k]}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ROWS.map(([label, get, better, fmt, hint]) => {
            const vals = present.map((k) => get(metrics[k], lanes[k]))
            const valid = vals.filter((v) => v != null)
            const best = valid.length > 1 ? (better === 'high' ? Math.max(...valid) : Math.min(...valid)) : null
            return (
              <tr key={label}>
                <td>{label}{hint && <span className="hint">{hint}</span>}</td>
                {vals.map((v, i) => (
                  <td key={present[i]} className={v != null && v === best ? 'best' : ''}>
                    {v == null ? '–' : fmt(v)}{v != null && v === best && <span className="hint">best</span>}
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

function Disagreements({ comparison, models, keys, ticketsById }) {
  if (!comparison || !comparison.disagreements.length) {
    return <div className="empty">When the models disagree on the level, the ticket shows up here.</div>
  }
  return (
    <div style={{ overflowX: 'auto' }}>
      <table className="disagree">
        <thead>
          <tr>
            <th scope="col">Ticket</th>
            <th scope="col">Answer key</th>
            {keys.map((k) => <th scope="col" key={k}>{models[k]}</th>)}
          </tr>
        </thead>
        <tbody>
          {comparison.disagreements.map((d) => (
            <tr key={d.ticket_id}>
              <td>
                <b>{d.ticket_id}</b>
                <div className="msg">{ticketsById[d.ticket_id]?.message}</div>
              </td>
              <td><b>{d.gold}</b>{d.difficulty === 'ambiguous' && <span className="hint">borderline</span>}</td>
              {keys.map((k) => {
                const a = d.answers[k]
                if (!a) return <td key={k}>–</td>
                return (
                  <td key={k}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                      <b>{a.level ?? 'invalid'}</b>
                      <span style={{ color: 'var(--ink-3)' }}>{pct(a.confidence)}</span>
                      <Mark correct={a.correct} compact />
                    </div>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function ComparisonTab({ live, tickets }) {
  const active = live.mode === 'comparison'
  useTicker(active && ['running', 'warming_up'].includes(live.status))
  const models = Object.fromEntries((live.config?.models || []).map((m) => [m.key, m.name]))
  const keys = live.config?.modes?.comparison || ['jev']
  const metrics = active ? live.metrics : {}
  const lanes = active ? live.lanes : {}
  const comparison = active ? live.comparison : null
  const present = keys.filter((k) => metrics[k])
  const ticketsById = Object.fromEntries(tickets.map((t) => [t.id, t]))
  const series = (get) => present.map((k) => ({ key: k, name: models[k], color: MODEL_COLOR[k], points: get(metrics[k]) }))
  const hasLanes = keys.some((k) => lanes[k])
  const raceClock = Math.max(0, ...keys.map((k) => laneNow(lanes[k])))

  return (
    <>
      <section className="panel" aria-labelledby="h-race">
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
          <h2 id="h-race">The race: same tickets, each model on its own</h2>
          {hasLanes && (
            <div style={{ textAlign: 'right' }}>
              <div className="clock">{seconds(raceClock)}</div>
              <div className="clock-label">Race clock</div>
            </div>
          )}
        </div>
        <p className="sub">
          Every model gets the same tickets in the same order and works through them independently, with the same pause
          between tickets. Each column counts the time that model spent answering; the faster model finishes first.
        </p>
        {hasLanes ? <RaceTrack lanes={lanes} keys={keys} /> : <div className="empty">Press “Run comparison” to start the race.</div>}
      </section>

      {hasLanes && (
        <div className="lanes-race section" style={{ '--n': keys.length }}>
          {keys.map((k) => <RaceLane key={k} lane={lanes[k]} color={MODEL_COLOR[k]} />)}
        </div>
      )}

      <section className="panel section" aria-labelledby="h-score">
        <h2 id="h-score">Scoreboard</h2>
        <p className="sub">Updated after every answer. Bold marks the best value in each row.</p>
        <Scoreboard metrics={metrics} lanes={lanes} models={models} keys={keys} />
      </section>

      <section className="panel section" aria-labelledby="h-diff">
        <h2 id="h-diff">Right answers: clear vs borderline tickets, and by support level</h2>
        <p className="sub">Level question only, as counts and percentages. Borderline tickets sit between two labels, so reviewers could reasonably disagree; each still has one answer in the key. The support level is how much work the ticket needs, from self-service (N0) to engineering (N3).</p>
        <DifficultyTables metrics={metrics} keys={keys} models={models} colors={MODEL_COLOR} />
      </section>

      {comparison && (
        <div className="tiles section">
          <Tile label="Tickets answered by every model" value={comparison.compared} />
          <Tile label="All models agree on level" value={pct(comparison.all_agree_rate)} />
          {keys.filter((k) => k !== 'jev').map((k) => {
            const v = comparison.pairwise_agreement[`jev|${k}`]
            return <Tile key={k} label={`JEV and ${models[k]} agree`} value={pct(v)} />
          })}
        </div>
      )}

      <div className="grid cols-2 section">
        <section className="panel">
          <h2>Latency per ticket</h2>
          <p className="sub">Log scale: each gridline is ten times the one below.</p>
          {present.length ? (
            <LineChart yLog yFormat={(v) => (v >= 1000 ? `${v / 1000} s` : `${v} ms`)}
              series={series((m) => m.latency.series.map((s) => ({ x: s.i, y: s.ms, label: s.ticket_id })))} />
          ) : <div className="empty">No data yet.</div>}
        </section>
        <section className="panel">
          <h2>Cumulative cost</h2>
          <p className="sub">Log scale. Prices are set in the backend .env file.</p>
          {present.length ? (
            <LineChart yLog yFormat={(v) => (v >= 1 ? `$${v}` : `$${+v.toPrecision(1)}`)}
              series={series((m) => m.cost.series.map((s) => ({ x: s.i, y: s.cum_usd, label: s.ticket_id })))} />
          ) : <div className="empty">No data yet.</div>}
        </section>
      </div>

      <section className="panel section">
        <h2>Accuracy by question</h2>
        <p className="sub">Share of tickets where each model's answer matches the answer key, for each of the five questions.</p>
        {present.length ? (
          <GroupedBars width={1200} height={240} groups={FIELDS.map((f) => FIELD_NAMES[f])} format={(v) => `${Math.round(v * 100)}%`}
            series={present.map((k) => ({ key: k, name: models[k], color: MODEL_COLOR[k], values: FIELDS.map((f) => metrics[k].accuracy.by_field[f]) }))} />
        ) : <div className="empty">No data yet.</div>}
      </section>

      <section className="panel section">
        <h2>When a model says it is sure, is it right?</h2>
        <p className="sub">
          Each model gives a confidence with every answer. The system acts on answers at or above the threshold
          ({pct(live.threshold)}) and escalates the rest. A trustworthy model is right far more often when it says it
          is sure, and rarely makes a confident mistake.
        </p>
        <ConfidenceSplit metrics={metrics} keys={keys} models={models} colors={MODEL_COLOR} />
      </section>

      <section className="panel section">
        <h2>Where the models disagree</h2>
        <p className="sub">Most recent first. These are the tickets worth discussing with the audience.</p>
        <Disagreements comparison={comparison} models={models} keys={keys} ticketsById={ticketsById} />
      </section>
    </>
  )
}
