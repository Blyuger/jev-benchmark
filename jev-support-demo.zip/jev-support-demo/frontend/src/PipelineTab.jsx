import { useEffect, useState } from 'react'
import { ConfusionMatrix, CoverageChart, GroupedBars, LineChart } from './charts.jsx'
import { ConfidenceSplit, DifficultyTables, Mark, OutcomeMark, TicketCard, Tile } from './components.jsx'
import { FIELDS, FIELD_NAMES, MODEL_COLOR, human, ms, pct, usd } from './format.js'

const LANES = [
  ['N0', 'Self-service bot'],
  ['N1', 'Support agent'],
  ['N2', 'Technical specialist'],
  ['N3', 'Engineering'],
  ['human', 'Senior human'],
]

function DecisionPanel({ payload }) {
  if (!payload) {
    return <div className="empty">JEV's answer appears here, with the probability of every option.</div>
  }
  const { result, routing, correct } = payload
  if (result.error) return <div className="banner error">Request failed: {result.error}</div>
  return (
    <div>
      <div className="questions">
        {FIELDS.map((f) => {
          const probs = result.probabilities?.[f]
          const rows = probs
            ? Object.entries(probs).sort((a, b) => b[1] - a[1]).slice(0, 4)
            : [[result.labels[f], result.confidence[f] ?? 0]]
          return (
            <div className="q" key={f}>
              <h3>{FIELD_NAMES[f]} <Mark correct={correct[f]} compact /></h3>
              {rows.map(([label, p]) => (
                <div className={`prob-row ${label === result.labels[f] ? 'chosen' : ''}`} key={label}>
                  <span className="lab" title={human(label)}>{human(label)}</span>
                  <div className="prob-track"><div className="prob-fill" style={{ width: `${(p || 0) * 100}%` }} /></div>
                  <span className="val">{pct(p)}</span>
                </div>
              ))}
            </div>
          )
        })}
      </div>
      <div className="verdict">
        <strong>{routing.queue_name}</strong>
        <span className="why">{routing.reason}</span>
        <OutcomeMark outcome={routing.outcome} />
        {routing.page_on_call && <span className="mark no">! Critical: page on-call</span>}
        <span className="spacer" />
        <span className="pill">Answered in {ms(result.latency_ms)}</span>
      </div>
    </div>
  )
}

function RoutingLanes({ feed, lastTicketId }) {
  const byQueue = Object.fromEntries(LANES.map(([q]) => [q, []]))
  feed.forEach((p) => byQueue[p.routing.queue]?.push(p))
  return (
    <div>
      <div className="lanes">
        {LANES.map(([q, name]) => (
          <div className="lane" key={q}>
            <div className="lane-head">
              <div><b>{q === 'human' ? 'Human' : q}</b><br /><span>{name}</span></div>
              <span className="lane-count">{byQueue[q].length}</span>
            </div>
            <div className="chips">
              {byQueue[q].map((p) => (
                <span key={p.ticket_id}
                  className={`chip ${p.routing.outcome} ${p.ticket_id === lastTicketId ? 'fresh' : ''}`}
                  title={`${p.ticket_id}: ${p.routing.reason}. Should go to ${p.routing.expected_queue}.`}>
                  {p.ticket_id.replace('T0', '').replace('T', '')}
                  {p.routing.outcome === 'unsafe' && ' !'}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="legend">
        <span><i className="key" style={{ borderColor: 'var(--good)' }} />Right queue</span>
        <span><i className="key" style={{ borderStyle: 'dashed', borderColor: 'var(--ink-3)' }} />More senior than needed (safe)</span>
        <span><i className="key" style={{ borderColor: 'var(--bad)', background: 'var(--bad-wash)' }} />Too junior (unsafe) !</span>
      </div>
    </div>
  )
}

export default function PipelineTab({ live, actions }) {
  const m = live.metrics.jev
  const feed = live.feed.filter((p) => p.model_key === 'jev')
  const payload = live.current?.results?.jev
  const [threshold, setThreshold] = useState(live.threshold)
  useEffect(() => setThreshold(live.threshold), [live.threshold])

  return (
    <>
      <div className="grid cols-ticket">
        <section className="panel" aria-labelledby="h-ticket">
          <h2 id="h-ticket">Incoming ticket</h2>
          <p className="sub">What the customer wrote. The answer key is shown for the audience only; JEV never sees it.</p>
          <TicketCard ticket={live.mode === 'pipeline' ? live.current?.ticket : null} />
        </section>
        <section className="panel" aria-labelledby="h-decision">
          <h2 id="h-decision">JEV's decision</h2>
          <p className="sub">Five typed questions answered in one call, each with calibrated probabilities.</p>
          <DecisionPanel payload={payload} />
        </section>
      </div>

      <section className="panel section" aria-labelledby="h-lanes">
        <h2 id="h-lanes">Where each ticket went</h2>
        <p className="sub">
          Code applies the rules: risk or an angry customer goes to a human; level confidence below {threshold.toFixed(2)} escalates one level.
        </p>
        <RoutingLanes feed={feed} lastTicketId={live.lastTicketId} />
      </section>

      <div className="tiles section">
        <Tile label="Tickets processed" value={m ? `${m.processed}` : '0'} note={m && live.total ? `of ${live.total}` : null} />
        <Tile label="Level accuracy" value={pct(m?.accuracy.by_field.level)} note={m ? `${m.level_correct} of ${m.processed}: support level N0 to N3 matches the answer key` : null} />
        <Tile label="Tickets with every label right" value={pct(m?.accuracy.all_fields)}
          note={m ? `${m.accuracy.all_fields_count} of ${m.processed}: level, category, priority, sentiment and risk all match` : null} />
        <Tile label="Latency (median)" value={ms(m?.latency.p50)} note={m ? `p95 ${ms(m.latency.p95)}, last ${ms(m.latency.last)}` : null} />
        <Tile label="Solved by self-service" value={pct(m?.routing.containment_rate)} note={m ? `${m.routing.human_overrides} sent to a human for risk or tone` : null} />
        <Tile label="Unsafe routings" value={m ? m.routing.outcomes.unsafe : '–'} note="Sent to a queue more junior than needed" />
        <Tile label="Risky tickets missed" value={m ? `${m.risk_detection.missed} of ${m.risk_detection.risky}` : '–'} note="Churn, legal or public exposure not flagged" />
        <Tile label="Cost per 1,000 tickets" value={usd(m?.cost.per_1k_tickets_usd)} note={m ? `${usd(m.cost.total_usd)} so far` : null} />
      </div>

      <div className="grid cols-2 section">
        <section className="panel">
          <h2>Latency per ticket</h2>
          <p className="sub">Time from request to answer, measured by the backend.</p>
          {m ? (
            <LineChart series={[{ key: 'jev', name: 'JEV', color: 'var(--jev)', points: m.latency.series.map((s) => ({ x: s.i, y: s.ms, label: s.ticket_id })) }]}
              yFormat={(v) => `${Math.round(v)} ms`} />
          ) : <div className="empty">No data yet.</div>}
        </section>
        <section className="panel">
          <h2>Which levels get confused</h2>
          <p className="sub">Rows are the answer key, columns are JEV's answer. The outlined diagonal is correct.</p>
          {m ? <ConfusionMatrix labels={m.level.labels} matrix={m.level.confusion} /> : <div className="empty">No data yet.</div>}
          {m && (
            <p className="sub" style={{ marginTop: 10 }}>
              Under-escalated {m.level.under_escalation} (worse), over-escalated {m.level.over_escalation}
              {m.level.severe_under_escalation > 0 && `, ${m.level.severe_under_escalation} by two levels or more`}.
            </p>
          )}
        </section>
      </div>

      <div className="grid cols-2 section">
        <section className="panel">
          <h2>When JEV says it is sure, is it right?</h2>
          <p className="sub">
            Level answers split by JEV's own confidence, at the threshold set on the right. The system acts on sure answers
            and escalates unsure ones, so a confident mistake is the costly kind.
          </p>
          <ConfidenceSplit metrics={live.metrics} keys={['jev']} models={{ jev: 'JEV' }} colors={MODEL_COLOR} />
        </section>
        <section className="panel">
          <h2>How much to automate</h2>
          <p className="sub">Raising the threshold automates fewer tickets, but the automated ones are more accurate.</p>
          {m ? <CoverageChart coverage={m.coverage} threshold={threshold} color="var(--jev)" /> : <div className="empty">No data yet.</div>}
          <label className="slider-row">
            Confidence threshold
            <input type="range" min="0" max="1" step="0.05" value={threshold}
              onChange={(e) => setThreshold(+e.target.value)}
              onMouseUp={(e) => actions.threshold(+e.target.value)}
              onKeyUp={(e) => actions.threshold(+e.target.value)}
              onTouchEnd={(e) => actions.threshold(+e.target.value)} />
            <b>{threshold.toFixed(2)}</b>
          </label>
        </section>
      </div>

      <section className="panel section">
        <h2>Right answers: clear vs borderline tickets, and by support level</h2>
        <p className="sub">Level question only, as counts and percentages. Borderline tickets sit between two labels, so reviewers could reasonably disagree; each still has one answer in the key. The support level is how much work the ticket needs, from self-service (N0) to engineering (N3).</p>
        <DifficultyTables metrics={live.metrics} keys={['jev']} models={{ jev: 'JEV' }} colors={MODEL_COLOR} />
      </section>

      <section className="panel section">
        <h2>Accuracy by question</h2>
        <p className="sub">Share of tickets where JEV's answer matches the answer key, for each of the five questions.</p>
        {m ? (
          <GroupedBars width={1200} height={240} groups={FIELDS.map((f) => FIELD_NAMES[f])} format={(v) => `${Math.round(v * 100)}%`}
            series={[{ key: 'jev', name: 'JEV', color: 'var(--jev)', values: FIELDS.map((f) => m.accuracy.by_field[f]) }]} />
        ) : <div className="empty">No data yet.</div>}
      </section>
    </>
  )
}
