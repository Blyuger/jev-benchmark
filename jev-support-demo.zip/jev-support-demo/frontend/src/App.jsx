import { useEffect, useState } from 'react'
import ComparisonTab from './ComparisonTab.jsx'
import { Controls, StatusLine } from './components.jsx'
import { useLive } from './live.js'
import PipelineTab from './PipelineTab.jsx'

const TABS = [
  ['pipeline', 'Pipeline'],
  ['comparison', 'Comparison'],
]

export default function App() {
  const [live, actions] = useLive()
  const [tab, setTab] = useState(() => (location.hash === '#comparison' ? 'comparison' : 'pipeline'))
  const [limit, setLimit] = useState(null)
  const [tickets, setTickets] = useState([])

  useEffect(() => { location.hash = tab }, [tab])
  useEffect(() => {
    fetch('/api/tickets').then((r) => r.json()).then(setTickets).catch(() => {})
  }, [live.connected])

  const cfg = live.config
  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <h1>Support triage with JEV</h1>
          <p>Ledgerly, a fictional SaaS. {cfg ? `${cfg.ticket_count} labeled tickets, levels N0 to N3.` : 'Connecting…'}</p>
        </div>
        <nav className="tabs" role="tablist" aria-label="Views">
          {TABS.map(([k, label]) => (
            <button key={k} className="tab" role="tab" aria-selected={tab === k} onClick={() => setTab(k)}>{label}</button>
          ))}
        </nav>
        <div className="spacer" />
        <Controls live={live} actions={actions} mode={tab} limit={limit} setLimit={setLimit} />
      </header>

      {cfg?.mock_mode && (
        <div className="banner mock" role="note">
          Mock mode: no API is called and every number on this page is simulated. Set MOCK_MODE=false in backend/.env for real results.
        </div>
      )}
      {cfg && cfg.missing_keys.length > 0 && (
        <div className="banner error" role="alert">
          Missing API keys in backend/.env: {cfg.missing_keys.join(', ')}. Add them, or set MOCK_MODE=true to rehearse.
        </div>
      )}
      {live.error && <div className="banner error" role="alert">{live.error}</div>}
      {live.status === 'error' && <div className="banner error" role="alert">The run stopped: {live.message}</div>}

      <StatusLine live={live} />

      {tab === 'pipeline' ? <PipelineTab live={live} actions={actions} /> : <ComparisonTab live={live} tickets={tickets} />}
    </div>
  )
}
