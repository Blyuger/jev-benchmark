"""Validate data/tickets.json against docs/labeling_guidelines.md.

Usage: python scripts/validate_gold.py [path/to/tickets.json]
Exit code 1 if any error is found (warnings don't fail).
"""
import json
import re
import sys
from collections import Counter
from pathlib import Path

LABELS = {
    "level": ["N0", "N1", "N2", "N3"],
    "category": ["account_access", "subscription", "cancellation", "invoicing", "payments",
                 "reports_exports", "integrations_api", "product_usage", "security"],
    "priority": ["low", "medium", "high", "critical"],
    "sentiment": ["positive", "neutral", "frustrated", "angry"],
    "risk": ["none", "churn", "legal", "public_exposure"],
}
CHANNELS = {"chat", "email", "whatsapp"}
PLANS = {"basic", "pro", "business", "accounting_firm"}
REQUIRED = ["id", "channel", "plan", "subject", "message", "gold", "difficulty", "rationale"]
# One gold label per question. Ambiguous tickets are adjudicated to a single label; what else was
# arguable goes in the rationale text, never into scoring.

# Keywords that signal explicit risk (guideline 5). Heuristic: a mismatch is a warning, not an error.
RISK_SIGNALS = {
    "legal": r"consumer protection|lawyer|attorney|lawsuit|\bsue\b|legal action|data protection authority|violat",
    "public_exposure": r"trustpilot|linkedin|instagram|social media|\bpress\b|\bexpose\b|\bpost (it|this|about|on)\b",
    "churn": r"want to cancel|i'll cancel|asked to cancel|cancel (my|our|the) subscription|\bpause\b"
             r"|switch to another|cheaper tool|whether to stay|signed up .*by mistake",
}
RISK_ORDER = ["legal", "public_exposure", "churn"]


def main(path: Path) -> int:
    errors, warnings = [], []
    tickets = json.loads(path.read_text(encoding="utf-8"))

    for i, c in Counter(t.get("id") for t in tickets).items():
        if c > 1:
            errors.append(f"Duplicate ID: {i}")
    for m, c in Counter(t.get("message") for t in tickets).items():
        if c > 1:
            errors.append(f"Duplicate message: {str(m)[:40]}")

    for t in tickets:
        tid = t.get("id", "?")
        missing = [f for f in REQUIRED if f not in t]
        if missing:
            errors.append(f"{tid}: missing fields {missing}")
            continue
        g, msg = t["gold"], t["message"].lower()

        # 1. Format
        if t["channel"] not in CHANNELS:
            errors.append(f"{tid}: invalid channel {t['channel']}")
        if t["plan"] not in PLANS:
            errors.append(f"{tid}: invalid plan {t['plan']}")
        for field, valid in LABELS.items():
            if g.get(field) not in valid:
                errors.append(f"{tid}: {field}={g.get(field)} not an allowed label")

        # 2. Difficulty and single gold label
        if t["difficulty"] not in ("clear", "ambiguous"):
            errors.append(f"{tid}: invalid difficulty {t['difficulty']}")
        if "alternatives" in t:
            errors.append(f"{tid}: 'alternatives' is not allowed; adjudicate to one gold label")
        if t["difficulty"] == "ambiguous" and "adjudicated" not in t["rationale"].lower():
            errors.append(f"{tid}: ambiguous ticket must say in its rationale how it was adjudicated")

        # 3. Label leakage in the message
        if re.search(r"\bn[0-3]\b|\blevel\b|\btier\b", msg):
            errors.append(f"{tid}: message mentions the level (label leakage)")

        # 4. Consistency rules
        if g["risk"] in ("legal", "public_exposure") and g["priority"] in ("low", "medium"):
            errors.append(f"{tid}: risk {g['risk']} requires high or critical priority")
        if g["priority"] == "critical" and g["level"] in ("N0", "N1"):
            errors.append(f"{tid}: critical priority with level {g['level']}")
        if g["level"] == "N0" and g["priority"] in ("high", "critical"):
            errors.append(f"{tid}: N0 with priority {g['priority']}")
        if g["category"] == "cancellation" and g["risk"] == "none":
            errors.append(f"{tid}: cancellation without risk")
        if g["sentiment"] == "positive" and g["risk"] != "none":
            warnings.append(f"{tid}: positive sentiment with risk {g['risk']}")

        # 5. Risk must be an explicit signal: cross-check keywords
        detected = next((r for r in RISK_ORDER if re.search(RISK_SIGNALS[r], msg)), "none")
        if detected != g["risk"]:
            warnings.append(f"{tid}: keywords suggest risk={detected}, gold={g['risk']} (review)")

    print(f"Tickets: {len(tickets)}  |  ambiguous: {sum(t.get('difficulty') == 'ambiguous' for t in tickets)}")
    for field, valid in LABELS.items():
        counts = Counter(t["gold"][field] for t in tickets if "gold" in t)
        print(f"  {field:10s} " + "  ".join(f"{v}={counts.get(v, 0)}" for v in valid))
        for v in valid:
            if counts.get(v, 0) < 3:
                warnings.append(f"Rare class: {field}={v} ({counts.get(v, 0)})")

    print(f"\nErrors: {len(errors)}")
    for e in errors:
        print("  x", e)
    print(f"Warnings: {len(warnings)}")
    for w in warnings:
        print("  !", w)
    return 1 if errors else 0


if __name__ == "__main__":
    default = Path(__file__).resolve().parent.parent / "data" / "tickets.json"
    sys.exit(main(Path(sys.argv[1]) if len(sys.argv) > 1 else default))
