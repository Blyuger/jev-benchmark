# Labeling Guidelines – JEV Support Triage Demo (N0–N3)

Fictional company: **Ledgerly**, a finance and invoicing SaaS for small businesses
(login, subscription, e-invoicing, payment links, reports, bank reconciliation, integrations, mobile app).

Every ticket gets 5 labels. The 5 questions are **independent**: `level` measures technical complexity,
not the customer's mood. Routing to a human because of sentiment or risk is the orchestrator's job.

## 1. Level (technical complexity to resolve)
| Level | Rule |
|---|---|
| **N0** | Solved with knowledge-base information or self-service. No action on the customer's account. |
| **N1** | Needs an action on the account or scripted basic troubleshooting (refund, unlock, plan change, permissions, error with a known fix). |
| **N2** | Needs technical investigation of ONE customer's specific case (logs, integrations, inconsistent data), or basic troubleshooting has already been exhausted. |
| **N3** | Product defect or incident: affects multiple customers, needs a code change, a product decision, a platform security fix, or involves an outage. |

## 2. Category
`account_access` (login, password, 2FA, users, permissions, account details) ·
`subscription` (plan, Ledgerly's own invoice, refunds, limits) ·
`cancellation` (request to end the subscription) ·
`invoicing` (issuing invoices, e-invoicing, invoice PDFs, signing certificates, tax portal) ·
`payments` (payment links, bank transfers and receivables the customer collects from *their* clients) ·
`reports_exports` (reports, P&L, cash flow, tax calculations, exports) ·
`integrations_api` (banks, reconciliation, online store, API, webhooks) ·
`product_usage` (how-to, records, imports, mobile app, performance) ·
`security` (unauthorized access, data leaks, privacy)

## 3. Priority (business impact)
| Priority | Rule |
|---|---|
| **low** | Question, no operational impact. |
| **medium** | Problem with a workaround, partial impact, or administrative request. |
| **high** | One customer's operation is blocked, financial impact, or legal/public-exposure risk. |
| **critical** | Incident affecting multiple customers, outage, data loss, or security breach. |

## 4. Sentiment
**positive** (explicit praise or thanks) · **neutral** · **frustrated** (dissatisfaction, disappointment, urgency, no hostility) ·
**angry** (hostility, insults, ALL CAPS, ultimatum or explicit threat).

## 5. Risk (explicit signal in the message)
**none** · **churn** (cancel, pause, switch to a competitor, or undo the purchase) · **legal** (consumer protection agency, lawyer, lawsuit,
data protection authority, "legal action", claim of a legal violation) · **public_exposure** (Trustpilot, social media, press).
If more than one applies: legal > public_exposure > churn.

## Ambiguity
Every ticket has exactly **one gold label per question**. Some tickets are genuinely borderline; those are
marked `"difficulty": "ambiguous"` and were **adjudicated**: a reviewer picked the single label that best fits
these guidelines. The rationale says so and records what else was arguable (for human review only).
Answers are never scored against those other options. The `ambiguous` flag is used only to report results
separately for clear and ambiguous tickets.

## How evaluation works
Exact match between the model's answer and the gold labels, field by field. No LLM-as-a-judge for classification.
- Accuracy per question, and the share of tickets with **all 5 labels right** (exact match ratio)
- Level: ordinal error → **under-escalation** (predicted below gold, the most harmful) vs **over-escalation**
- Answers outside the allowed labels (LLMs) count as errors and are also counted separately

## Known bias
The gold labels were drafted by a Claude model. Have a person on your team review at least the ambiguous tickets
before presenting, and mention this in the demo.
