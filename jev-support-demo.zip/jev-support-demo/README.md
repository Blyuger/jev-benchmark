# Support Triage with JEV

A live demo of **JEV** (TypeSafe's System One decision model) triaging customer-support tickets into
levels **N0 to N3**, plus a live race against **Claude Haiku 4.5**, **Claude Sonnet 5.5**, **GPT-6 Luna** and
**GPT-6.1 Sol**.

The model decides, plain code applies the rules, and every answer is scored against a labeled answer key
in real time.

```
ticket ──► JEV: 5 typed questions in one call ──► router (code) ──► queue
           level · category · priority · sentiment · risk     N0 self-service bot
           each with calibrated probabilities                   N1 support agent
                                                                N2 technical specialist
                                                                N3 engineering
                                                                Human (risk or angry customer)
```

## What the demo shows

**Pipeline tab** (JEV only)
- The incoming ticket and JEV's probability for every option of the 5 questions
- The routing decision and why (risk override, angry customer, low-confidence escalation)
- Routing lanes: every ticket drops into the queue it was sent to, marked right, safe (too senior) or unsafe (too junior)
- Live metrics: level accuracy, tickets with every label right, latency, containment, unsafe routings, missed risk, cost
- Confusion matrix, a "when JEV says it is sure, is it right?" table, and a threshold slider that shows the
  automation-vs-accuracy trade-off
- Right answers for clear vs borderline tickets and by support level, as counts and percentages

**Comparison tab** (5 models, each running as its own independent process)
- The race: every model works through the same tickets back to back, at its own speed, with the same pause
  between tickets. A race clock on top, a progress bar per model, and one column per model showing the ticket it
  is working on, a live timer for the request in flight, its time spent answering, and its latest answers
- Finish order and finish time for each model
- Scoreboard with the best value per metric, including time to finish all tickets
- Right answers per model, as counts and percentages: clear vs borderline tickets, and by
  support level N0 to N3
- Latency and cumulative cost per ticket, accuracy per question
- "When a model says it is sure, is it right?": each model's level answers split at the routing threshold into
  sure and unsure, right and wrong, with a count of confident mistakes
- Agreement rates and a feed of the tickets where the models disagree

## Quick start

Requirements: [uv](https://docs.astral.sh/uv/) (it installs Python 3.11+ for you if needed) and Node 20+.
With `uv run` there is no need to activate the virtual environment.

### Windows (PowerShell)

```powershell
# 0. Install uv once, then close and reopen the terminal
winget install --id=astral-sh.uv -e

# 1. Backend (first terminal)
cd jev-support-demo\backend
uv venv
uv pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env                  # add TYPESAFE_API_KEY, ANTHROPIC_API_KEY and OPENAI_API_KEY, save and close
uv run uvicorn app.main:app --port 8000

# 2. Frontend (second terminal)
cd jev-support-demo\frontend
npm install
npm run dev                   # open http://localhost:5173
```

### macOS / Linux

```bash
# 0. Install uv once
curl -LsSf https://astral.sh/uv/install.sh | sh

# 1. Backend (first terminal)
cd jev-support-demo/backend
uv venv
uv pip install -r requirements.txt
cp .env.example .env          # add TYPESAFE_API_KEY, ANTHROPIC_API_KEY and OPENAI_API_KEY
uv run uvicorn app.main:app --port 8000

# 2. Frontend (second terminal)
cd jev-support-demo/frontend
npm install
npm run dev                   # open http://localhost:5173
```

### Tests and answer-key validation

```powershell
# Inside backend/
uv run pytest

# From the project root (uses only the standard library)
uv run python scripts/validate_gold.py
```

**Single port for presenting:** run `npm run build` in `frontend/` once; the backend then serves the UI at
http://localhost:8000.

**Missing a key?** Remove those models from `COMPARISON_MODELS` in `.env` (for example
`COMPARISON_MODELS=jev,haiku,sonnet` without an OpenAI key).

**Rehearse without spending API credits:** set `MOCK_MODE=true` in `backend/.env` and restart the backend.
No API is called and a banner on every page says the numbers are simulated. Mock numbers say nothing about
any model.

## Suggested demo script (about 10 minutes)

1. **Pipeline, 1× speed, 20 tickets.** Read one ticket aloud, then point at JEV's five probability bars and
   the routing reason. Let the lanes fill.
2. **Point at an override** in the Human lane, such as T037 (consumer protection threat) or T042 (Trustpilot
   threat): technically N1, but sent to a human. Sentiment and risk are separate questions from level.
3. **Move the threshold slider** from 0.50 to 0.90 and show tickets moving between lanes, and the coverage
   chart trading volume for accuracy.
4. **Comparison, 1× speed, 20 tickets.** Start the race and let the audience watch: JEV's bar runs ahead, its
   "time spent answering" stays low, and it finishes first while the others are still working.
5. **Read the results:** finish times, the scoreboard, then the clear vs borderline tables (who holds up on borderline
   tickets and on N3). Finish on the disagreement feed: these are the cases worth discussing.

## How evaluation works

- **Exact match** against `data/tickets.json`, field by field. No LLM-as-a-judge: the outputs are closed labels,
  so comparison with the answer key is instant, free, reproducible and unbiased.
- **One gold label per question, no partial credit.** The 26 borderline tickets were adjudicated to a single
  label (their rationale records what else was arguable, for human review only). This follows standard practice
  for classification benchmarks: disagreement is resolved into one gold label, then scored with plain accuracy.
- **Tickets with every label right** (exact match ratio): the ticket counts only if level, category, priority,
  sentiment and risk all match the answer key.
- **Level errors have a direction.** Under-escalation (predicted too low) is worse than over-escalation.
- **Routing outcome** compares the queue chosen at the current threshold with the queue the answer key implies:
  correct, safe (more senior than needed) or unsafe (too junior, or a human case missed).
- **Sure vs unsure** (level question): answers with confidence at or above the routing threshold are "sure" (the
  system acts on them), the rest "unsure" (escalated). The table shows accuracy in each group and the number of
  **confident mistakes**, wrong answers the model was sure about. It follows the threshold slider.
- **Brier score** pools every decision (ticket × question): the average of (confidence − 1 if right, 0 if wrong)².
  0 is perfect; lower is better. ECE is still computed and included in `/api/export`.
- Failed requests and labels outside the taxonomy count as wrong and are also counted separately.
- **Clear vs borderline, and by support level:** level-question accuracy for clear and borderline tickets, and for each support level in the
  answer key (N0 to N3), shown as "x of y" and as a percentage.
- Latency is wall-clock time measured by the backend for each request, after one unmeasured warm-up call per
  model. In the comparison race every model starts at the same instant and then runs independently; "time spent
  answering" is the sum of that model's request latencies, and "time to finish" is the race clock when it
  answered its last ticket (it includes the same fixed pause between tickets for every model).

### Fairness of the comparison

- Every model gets the same ticket text and the same labels and definitions, generated from one file
  (`backend/app/taxonomy.py`).
- Claude and GPT use structured outputs with the same JSON schema, whose enums are the allowed labels.
- **Every model is set for low latency:** Claude Sonnet 5.5 with `effort: "low"`, GPT-6 Luna and GPT-6.1 Sol with
  `reasoning.effort: "low"`. Claude Haiku 4.5 has no effort parameter and runs without extended thinking, its
  fastest setting. JEV has no reasoning setting; it always decides in a single pass. Each column in the race shows
  its setting.
- The LLMs' confidence is self-reported in their answer; JEV's is a calibrated probability. That difference is
  one of the things the demo measures, not something it assumes.

### Known limitations

- The answer key was drafted by a Claude model. Have someone on your team review at least the 26 borderline
  tickets, and mention this when presenting.
- 88 tickets is a demo set, not a benchmark. Differences of a few points are within noise.
- Prices in `.env` are defaults; check each provider's current pricing before quoting costs to a client.

## Reusing it for another client

1. Rewrite `docs/labeling_guidelines.md` for the client's domain.
2. Update the labels and definitions in `backend/app/taxonomy.py` to match.
3. Replace `data/tickets.json` (same fields: `id, channel, plan, subject, message, gold, difficulty, rationale`; one gold label per question).
4. Run `python scripts/validate_gold.py` until it reports 0 errors (update its label lists and risk keywords too).
5. Rehearse in mock mode, then switch to real keys.

## Project layout

```
backend/
  app/taxonomy.py        the 5 questions, labels and definitions (single source of truth)
  app/classifiers/       jev.py (raw HTTP), claude.py, openai.py (Responses API), llm_prompt.py (shared prompt
                         and schema for the LLMs), mock.py
  app/router.py          routing rules applied in code
  app/metrics.py         all metrics, computed from stored records
  app/runner.py          replay engine: one independent worker per model, streams events over WebSocket
  app/main.py            FastAPI: REST controls + /ws
  tests/                 unit tests (pytest)
frontend/src/
  PipelineTab.jsx, ComparisonTab.jsx, charts.jsx (SVG charts), live.js (WebSocket state)
data/tickets.json        88 labeled tickets
docs/labeling_guidelines.md
scripts/validate_gold.py
```

## API

| Method | Path | Body |
|---|---|---|
| POST | `/api/run` | `{"mode": "pipeline" \| "comparison", "speed": 1, "shuffle": true, "limit": null}` |
| POST | `/api/pause`, `/api/resume`, `/api/stop` | |
| POST | `/api/speed` | `{"speed": 5}` (0 = as fast as possible) |
| POST | `/api/threshold` | `{"value": 0.8}` |
| GET | `/api/state`, `/api/config`, `/api/tickets` | |
| GET | `/api/export` | full metrics and per-ticket records as JSON (for slides) |
| WS | `/ws` | events: `state, status, ticket, lane, result, metrics, comparison` |

Tests: `cd backend` then `uv run pytest`.
