"""Unit tests: routing rules, metrics math, JEV/Claude response parsing, and a full mock run."""
import json
import os

os.environ["MOCK_LATENCY_SCALE"] = "0"

import httpx
import pytest

from app.classifiers.base import empty_result, normalize_label
from app.classifiers.claude import build_schema, parse_output
from app.classifiers.jev import JevClassifier, build_questions, parse_response
from app.config import Settings
from app.metrics import ModelMetrics, calibration, percentile
from app.router import gold_route, route, routing_outcome
from app.runner import RunManager
from app.taxonomy import FIELDS, LABELS

GOLD = {"level": "N2", "category": "invoicing", "priority": "high", "sentiment": "neutral", "risk": "none"}
CONF = {f: 0.9 for f in FIELDS}


# ---------- router ----------
def test_route_by_level():
    assert route(GOLD, CONF, 0.75)["queue"] == "N2"
    assert route({**GOLD, "level": "N0", "priority": "low"}, CONF, 0.75)["kind"] == "auto_resolved"


def test_risk_and_anger_go_to_human():
    assert route({**GOLD, "risk": "legal"}, CONF, 0.75)["queue"] == "human"
    assert route({**GOLD, "risk": "public_exposure"}, CONF, 0.75)["queue"] == "human"
    assert route({**GOLD, "sentiment": "angry"}, CONF, 0.75)["queue"] == "human"
    assert route({**GOLD, "risk": "churn"}, CONF, 0.75)["queue"] == "N2"  # churn alone doesn't override


def test_low_confidence_escalates_one_level():
    d = route(GOLD, {**CONF, "level": 0.5}, 0.75)
    assert d["queue"] == "N3" and d["kind"] == "low_confidence"
    assert route({**GOLD, "level": "N3"}, {**CONF, "level": 0.5}, 0.75)["queue"] == "human"


def test_invalid_output_goes_to_human():
    assert route({**GOLD, "level": None}, CONF, 0.75)["kind"] == "invalid"


def test_routing_outcome():
    assert routing_outcome("N2", "N2") == "correct"
    assert routing_outcome("N3", "N2") == "safe"
    assert routing_outcome("N1", "N2") == "unsafe"
    assert routing_outcome("N3", "human") == "unsafe"
    assert gold_route({**GOLD, "risk": "legal"})["queue"] == "human"


# ---------- metrics ----------
def test_percentile():
    assert percentile([1, 2, 3, 4, 5], 50) == 3
    assert percentile([], 50) is None
    assert percentile([10, 20], 95) == pytest.approx(19.5)


def test_calibration_perfect_and_overconfident():
    perfect = [(0.8, True)] * 8 + [(0.8, False)] * 2
    assert calibration(perfect)["ece"] == pytest.approx(0.0)
    over = [(0.95, True)] * 5 + [(0.95, False)] * 5
    c = calibration(over)
    assert c["ece"] == pytest.approx(0.45)
    assert c["brier"] == pytest.approx((5 * 0.05 ** 2 + 5 * 0.95 ** 2) / 10)


def _result(labels, conf=0.9, latency=100, cost=0.001, key="jev"):
    r = empty_result(key, "T1")
    r.labels.update(labels)
    r.confidence.update({f: conf for f in FIELDS})
    r.latency_ms, r.cost_usd = latency, cost
    return r


def test_exact_match_and_escalation_direction():
    m = ModelMetrics("jev", "JEV", "calibrated")
    t1 = {"id": "T1", "gold": GOLD, "difficulty": "ambiguous"}
    t2 = {"id": "T2", "gold": GOLD, "difficulty": "clear"}
    t3 = {"id": "T3", "gold": GOLD, "difficulty": "clear"}
    m.add(_result({**GOLD, "level": "N3"}), t1)  # wrong (no partial credit), over-escalation
    m.add(_result(GOLD), t2)                      # exact
    m.add(_result({**GOLD, "level": "N0"}), t3)   # severe under-escalation
    s = m.snapshot(0.75)
    assert s["accuracy"]["by_field"]["level"] == pytest.approx(1 / 3)
    assert s["accuracy"]["all_fields"] == pytest.approx(1 / 3) and s["accuracy"]["all_fields_count"] == 1
    assert s["level"]["over_escalation"] == 1
    assert s["level"]["under_escalation"] == 1
    assert s["level"]["severe_under_escalation"] == 1
    assert s["level"]["confusion"][2] == [1, 0, 1, 1, 0]
    assert s["routing"]["outcomes"] == {"correct": 1, "safe": 1, "unsafe": 1}
    assert s["cost"]["per_1k_tickets_usd"] == pytest.approx(1.0)


def test_errors_count_as_wrong_and_are_excluded_from_latency():
    m = ModelMetrics("haiku", "Haiku", "self_reported")
    bad = empty_result("haiku", "T1")
    bad.error, bad.latency_ms = "HTTP 500", 9999
    m.add(bad, {"id": "T1", "gold": GOLD})
    m.add(_result(GOLD, latency=200, key="haiku"), {"id": "T2", "gold": GOLD})
    s = m.snapshot(0.75)
    assert s["errors"] == 1
    assert s["accuracy"]["by_field"]["level"] == 0.5
    assert s["confidence_split"]["no_answer"] == 1  # the failed request is in neither group
    assert s["latency"]["max"] == 200
    assert s["routing"]["kinds"]["invalid"] == 1


# ---------- parsing ----------
def test_normalize_label_case_insensitive():
    assert normalize_label("level", "n2") == "N2"
    assert normalize_label("risk", "Public_Exposure") == "public_exposure"
    assert normalize_label("risk", "lawsuit") is None


def test_jev_request_shape():
    q = build_questions()
    assert set(q) == set(FIELDS)
    assert all(v["type"] == "choice" and set(v["criteria"]) == set(LABELS[k]) for k, v in q.items())


def test_jev_response_parsing():
    data = {"model": "jev-1.13.0", "usage": {"input_tokens": 900, "output_tokens": 5}, "answers": {
        f: {"type": "choice", "choice": GOLD[f], "confidence": 0.8,
            "probabilities": {GOLD[f]: 0.8, **{l: 0.2 / (len(LABELS[f]) - 1) for l in LABELS[f] if l != GOLD[f]}}}
        for f in FIELDS}}
    data["answers"]["risk"]["choice"] = "unknown"
    r = empty_result("jev", "T1")
    parse_response(data, r)
    assert r.labels["level"] == "N2" and r.confidence["level"] == 0.8
    assert r.labels["risk"] is None and r.invalid_fields == ["risk"]
    assert r.input_tokens == 900 and r.model_version == "jev-1.13.0"


@pytest.mark.asyncio
async def test_jev_http_call_with_retry():
    calls = {"n": 0}

    def handler(request: httpx.Request):
        calls["n"] += 1
        body = json.loads(request.content)
        assert request.url.path == "/v1/systemone"
        assert request.headers["authorization"] == "Bearer test-key"
        assert body["model"] == "jev-1.13.0" and "gold" not in body["state"]
        if calls["n"] == 1:
            return httpx.Response(429, json={"error": "busy"})
        return httpx.Response(200, json={"model": "jev-1.13.0", "usage": {"input_tokens": 10},
                                         "answers": {f: {"choice": GOLD[f], "confidence": 0.9} for f in FIELDS}})

    s = Settings()
    s.typesafe_api_key = "test-key"
    c = JevClassifier(s.model("jev"), s)
    c.client = httpx.AsyncClient(transport=httpx.MockTransport(handler),
                                 headers={"Authorization": "Bearer test-key"})
    ticket = {"id": "T1", "channel": "chat", "plan": "pro", "subject": "x", "message": "y", "gold": GOLD}
    r = await c.classify(ticket)
    await c.close()
    assert r.error is None and r.retries == 1 and r.labels == GOLD


def test_claude_schema_and_parsing():
    schema = build_schema()
    assert schema["properties"]["level"]["properties"]["label"]["enum"] == LABELS["level"]
    r = empty_result("sonnet", "T1")
    parse_output(json.dumps({f: {"label": GOLD[f].upper() if f == "level" else GOLD[f], "confidence": 1.4}
                             for f in FIELDS}), r)
    assert r.labels == GOLD and r.confidence["level"] == 1.0  # case-insensitive, clamped
    r2 = empty_result("sonnet", "T1")
    parse_output("not json", r2)
    assert r2.invalid_fields == FIELDS


# ---------- full run ----------
@pytest.mark.asyncio
async def test_full_mock_comparison_run():
    s = Settings()
    s.mock_mode = True
    m = RunManager(s)
    events = []

    class WS:
        async def accept(self): ...
        async def send_json(self, e): events.append(e["type"])

    await m.connect(WS())
    await m.start("comparison", speed=0, shuffle=True, limit=12, seed=1)
    await m._task
    st = m.state()
    assert st["status"] == "finished"
    keys = ("jev", "haiku", "sonnet", "luna", "sol")
    assert all(st["metrics"][k]["processed"] == 12 for k in keys)
    assert st["comparison"]["compared"] == 12
    assert events.count("result") == 60
    # Each model is its own process: every lane finished, ranks are 1..5 with no ties
    assert sorted(st["lanes"][k]["rank"] for k in keys) == [1, 2, 3, 4, 5]
    assert all(st["lanes"][k]["state"] == "finished" and st["lanes"][k]["done"] == 12 for k in keys)
    await m.set_threshold(0.95)
    assert m.state()["metrics"]["jev"]["routing"]["threshold"] == 0.95


# ---------- difficulty ----------
def test_accuracy_by_difficulty_counts_and_rates():
    m = ModelMetrics("jev", "JEV", "calibrated")
    clear = {"gold": GOLD, "difficulty": "clear"}
    amb = {"gold": GOLD, "difficulty": "ambiguous"}
    m.add(_result(GOLD), {"id": "A", **clear})
    m.add(_result({**GOLD, "level": "N1"}), {"id": "B", **clear})
    m.add(_result(GOLD), {"id": "C", **amb})
    m.add(_result({**GOLD, "level": "N3"}), {"id": "D", **amb})
    s = m.snapshot(0.75)
    d = s["by_difficulty"]
    assert d["clear"]["total"] == 2 and d["clear"]["level"] == {"correct": 1, "rate": 0.5}
    assert d["ambiguous"]["level"] == {"correct": 1, "rate": 0.5}
    assert d["clear"]["all_fields"]["correct"] == 1
    assert s["by_level"]["N2"]["total"] == 4 and s["by_level"]["N0"]["total"] == 0
    assert s["by_level"]["N0"]["level"]["rate"] is None


def test_sure_vs_unsure_split_follows_threshold():
    m = ModelMetrics("haiku", "Haiku", "self_reported")
    t = {"gold": GOLD, "difficulty": "clear"}
    m.add(_result(GOLD, conf=0.95), {"id": "A", **t})                      # sure, right
    m.add(_result({**GOLD, "level": "N0"}, conf=0.90), {"id": "B", **t})   # sure, wrong: confident mistake
    m.add(_result({**GOLD, "level": "N1"}, conf=0.60), {"id": "C", **t})   # unsure, wrong
    m.add(_result(GOLD, conf=0.50), {"id": "D", **t})                      # unsure, right
    c = m.snapshot(0.75)["confidence_split"]
    assert c["sure"] == {"total": 2, "right": 1, "wrong": 1, "accuracy": 0.5}
    assert c["unsure"] == {"total": 2, "right": 1, "wrong": 1, "accuracy": 0.5}
    c = m.snapshot(0.92)["confidence_split"]   # raising the threshold moves B to "unsure"
    assert c["sure"]["total"] == 1 and c["sure"]["wrong"] == 0


def test_dataset_has_single_gold_labels():
    from app.config import Settings as S
    tickets = json.loads(S().tickets_path.read_text(encoding="utf-8"))
    assert all("alternatives" not in t for t in tickets)
    assert all(set(t["gold"]) == set(FIELDS) for t in tickets)


# ---------- OpenAI + effort ----------
@pytest.mark.asyncio
async def test_openai_request_uses_low_effort_and_strict_schema():
    from app.classifiers.openai import OpenAIClassifier, extract_text
    seen = {}

    def handler(request: httpx.Request):
        seen.update(json.loads(request.content))
        assert request.url.path.endswith("/responses")
        answer = json.dumps({f: {"label": GOLD[f], "confidence": 0.7} for f in FIELDS})
        return httpx.Response(200, json={
            "model": "gpt-6-luna", "usage": {"input_tokens": 1000, "output_tokens": 200},
            "output": [{"type": "reasoning", "summary": []},
                       {"type": "message", "content": [{"type": "output_text", "text": answer}]}]})

    s = Settings()
    s.openai_api_key = "k"
    c = OpenAIClassifier(s.model("luna"), s)
    c.client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    r = await c.classify({"id": "T1", "channel": "chat", "plan": "pro", "subject": "x", "message": "y", "gold": GOLD})
    await c.close()
    assert seen["reasoning"] == {"effort": "low"}
    assert seen["text"]["format"]["type"] == "json_schema" and seen["text"]["format"]["strict"] is True
    assert "gold" not in seen["input"]
    assert r.error is None and r.labels == GOLD and r.confidence_source == "self_reported"
    assert r.cost_usd == pytest.approx((1000 * 0.10 + 200 * 0.50) / 1e6)
    assert extract_text({"output_text": "abc"}) == "abc"


def test_effort_settings_per_model():
    from app.classifiers.claude import ClaudeClassifier
    s = Settings()
    s.anthropic_api_key = "k"
    assert ClaudeClassifier(s.model("sonnet"), s).output_config["effort"] == "low"
    assert "effort" not in ClaudeClassifier(s.model("haiku"), s).output_config  # Haiku has no effort param
    assert s.model("sol").effort == "low" and s.model("jev").effort is None


def test_missing_keys_only_for_models_in_use():
    s = Settings()
    s.mock_mode = False
    s.typesafe_api_key, s.anthropic_api_key, s.openai_api_key = "a", "b", ""
    assert s.missing_keys(["jev"]) == []
    assert s.missing_keys(["jev", "luna"]) == ["OPENAI_API_KEY"]
