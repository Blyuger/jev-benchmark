"""Orchestrator rules: turn classification labels + confidence into a routing decision.

This is deliberately plain code. The model decides, the code applies the threshold and the
business rules, so trust and fallback stay deterministic and auditable.
"""
from __future__ import annotations

from typing import Optional

from .taxonomy import LEVEL_ORDER

QUEUES = {
    "N0": "Self-service bot",
    "N1": "Support agent (N1)",
    "N2": "Technical specialist (N2)",
    "N3": "Engineering (N3)",
    "human": "Senior human (priority)",
}
# Seniority used to judge whether a routing mistake is safe (too senior) or unsafe (too junior).
SENIORITY = {"N0": 0, "N1": 1, "N2": 2, "N3": 3, "human": 4}


def route(labels: dict[str, Optional[str]], confidence: dict[str, Optional[float]],
          threshold: float) -> dict:
    level = labels.get("level")
    risk = labels.get("risk")
    sentiment = labels.get("sentiment")
    page_on_call = labels.get("priority") == "critical"

    if level is None:
        return _decision("human", "Model output invalid: sent to a human", "invalid", page_on_call)
    if risk in ("legal", "public_exposure"):
        return _decision("human", f"Risk detected ({risk.replace('_', ' ')}): human takes over",
                         "risk_override", page_on_call)
    if sentiment == "angry":
        return _decision("human", "Angry customer: human takes over", "sentiment_override", page_on_call)

    conf = confidence.get("level")
    if conf is not None and conf < threshold:
        i = LEVEL_ORDER.index(level)
        if i + 1 < len(LEVEL_ORDER):
            nxt = LEVEL_ORDER[i + 1]
            return _decision(nxt, f"Low confidence ({conf:.2f} < {threshold:.2f}): escalated {level} → {nxt}",
                             "low_confidence", page_on_call)
        return _decision("human", f"Low confidence ({conf:.2f} < {threshold:.2f}) on N3: human review",
                         "low_confidence", page_on_call)

    reason = "Resolved by self-service" if level == "N0" else f"Routed to {QUEUES[level]}"
    return _decision(level, reason, "auto_resolved" if level == "N0" else "routed", page_on_call)


def gold_route(gold: dict) -> dict:
    """Where the ticket should go if the labels were perfect and fully confident."""
    return route(gold, {k: 1.0 for k in gold}, threshold=0.0)


def routing_outcome(predicted_queue: str, gold_queue: str) -> str:
    """correct | safe (more senior than needed) | unsafe (too junior, or a human case missed)."""
    if predicted_queue == gold_queue:
        return "correct"
    return "safe" if SENIORITY[predicted_queue] > SENIORITY[gold_queue] else "unsafe"


def _decision(queue: str, reason: str, kind: str, page_on_call: bool) -> dict:
    return {"queue": queue, "queue_name": QUEUES[queue], "reason": reason, "kind": kind,
            "page_on_call": page_on_call}
