"""Single source of truth for the 5 triage questions.

Both the JEV request (choice criteria) and the Claude prompt (JSON schema enums + descriptions)
are generated from this module, so every model sees exactly the same labels and definitions.
Keep it in sync with docs/labeling_guidelines.md.
"""
from __future__ import annotations

COMPANY_CONTEXT = (
    "Ledgerly is a finance and invoicing SaaS for small businesses (login, subscription, e-invoicing, "
    "payment links, reports, bank reconciliation, integrations, mobile app). The text is a support "
    "ticket written by a Ledgerly customer."
)

# field -> (instructions, {label: description})
QUESTIONS: dict[str, tuple[str, dict[str, str]]] = {
    "level": (
        "Support level needed to resolve this ticket, based only on technical complexity "
        "(ignore the customer's mood).",
        {
            "N0": "Solved with knowledge-base information or self-service. No action on the customer's account.",
            "N1": "Needs an action on the account or scripted basic troubleshooting (refund, unlock, plan change, "
                  "permissions, error with a known fix).",
            "N2": "Needs technical investigation of ONE customer's specific case (logs, integrations, inconsistent "
                  "data), or basic troubleshooting has already been exhausted.",
            "N3": "Product defect or incident: affects multiple customers, needs a code change, a product decision, "
                  "a platform security fix, or involves an outage.",
        },
    ),
    "category": (
        "Main topic of the ticket.",
        {
            "account_access": "Login, password, 2FA, users, permissions, account details.",
            "subscription": "The customer's Ledgerly plan, Ledgerly's own invoice, refunds, limits.",
            "cancellation": "Request to end the Ledgerly subscription.",
            "invoicing": "Issuing invoices, e-invoicing, invoice PDFs, signing certificates, tax portal.",
            "payments": "Payment links, bank transfers and receivables the customer collects from their own clients.",
            "reports_exports": "Reports, P&L, cash flow, tax calculations, exports.",
            "integrations_api": "Banks, reconciliation, online store, API, webhooks.",
            "product_usage": "How-to questions, records, imports, mobile app, performance.",
            "security": "Unauthorized access, data leaks, privacy.",
        },
    ),
    "priority": (
        "Business impact of the ticket.",
        {
            "low": "Question, no operational impact.",
            "medium": "Problem with a workaround, partial impact, or administrative request.",
            "high": "One customer's operation is blocked, financial impact, or legal/public-exposure risk.",
            "critical": "Incident affecting multiple customers, outage, data loss, or security breach.",
        },
    ),
    "sentiment": (
        "Emotional tone of the customer.",
        {
            "positive": "Explicit praise or thanks.",
            "neutral": "No clear emotion.",
            "frustrated": "Dissatisfaction, disappointment or urgency, without hostility.",
            "angry": "Hostility, insults, ALL CAPS, an ultimatum or an explicit threat.",
        },
    ),
    "risk": (
        "Business risk explicitly signaled in the message. If more than one applies: "
        "legal > public_exposure > churn.",
        {
            "none": "No explicit risk signal.",
            "churn": "Mentions cancelling, pausing, switching to a competitor, or undoing the purchase.",
            "legal": "Mentions a consumer protection agency, lawyer, lawsuit, data protection authority, "
                     "legal action, or claims a legal violation.",
            "public_exposure": "Mentions Trustpilot, social media, press or posting publicly about it.",
        },
    ),
}

FIELDS: list[str] = list(QUESTIONS)
LABELS: dict[str, list[str]] = {f: list(opts) for f, (_, opts) in QUESTIONS.items()}
LEVEL_ORDER = LABELS["level"]  # N0 < N1 < N2 < N3


def ticket_state(ticket: dict) -> str:
    """Text sent to every model. Gold labels and rationale are never included."""
    return (
        f"Channel: {ticket['channel']}\n"
        f"Customer plan: {ticket['plan']}\n"
        f"Subject: {ticket['subject']}\n"
        f"Message: {ticket['message']}"
    )
