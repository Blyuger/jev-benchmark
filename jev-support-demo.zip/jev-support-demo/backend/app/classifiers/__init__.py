from ..config import Settings
from .base import Classifier, ClassificationResult


def build_classifier(key: str, settings: Settings) -> Classifier:
    spec = settings.model(key)
    if settings.mock_mode:
        from .mock import MockClassifier
        return MockClassifier(spec)
    if spec.provider == "jev":
        from .jev import JevClassifier
        return JevClassifier(spec, settings)
    if spec.provider == "openai":
        from .openai import OpenAIClassifier
        return OpenAIClassifier(spec, settings)
    from .claude import ClaudeClassifier
    return ClaudeClassifier(spec, settings)


__all__ = ["Classifier", "ClassificationResult", "build_classifier"]
