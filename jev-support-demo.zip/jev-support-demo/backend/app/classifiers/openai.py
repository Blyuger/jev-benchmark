"""OpenAI classifier (GPT-6 Luna / GPT-6.1 Sol) over the Responses API, raw HTTP.

Same prompt and JSON schema as Claude. Latency setting: `reasoning.effort = "low"`.
Docs: POST {base}/responses with text.format = json_schema (strict).
"""
from __future__ import annotations

import asyncio
import time

import httpx

from ..config import ModelSpec, Settings
from ..taxonomy import ticket_state
from .base import Classifier, ClassificationResult, empty_result
from .llm_prompt import SCHEMA, SYSTEM_PROMPT, parse_output

RETRY_STATUS = {429, 500, 502, 503, 504}
MAX_RETRIES = 3


def extract_text(data: dict) -> str:
    """Text of the first output message (raw HTTP responses have no `output_text` shortcut)."""
    if isinstance(data.get("output_text"), str):
        return data["output_text"]
    for item in data.get("output") or []:
        if item.get("type") == "message":
            for part in item.get("content") or []:
                if part.get("type") == "output_text":
                    return part.get("text", "")
    return ""


class OpenAIClassifier(Classifier):
    def __init__(self, spec: ModelSpec, settings: Settings):
        self.key = spec.key
        self.spec = spec
        self.url = settings.openai_base_url.rstrip("/") + "/responses"
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_s,
            headers={"Authorization": f"Bearer {settings.openai_api_key}",
                     "Content-Type": "application/json"},
        )

    def _payload(self, ticket: dict) -> dict:
        body = {
            "model": self.spec.model_id,
            "instructions": SYSTEM_PROMPT,
            "input": ticket_state(ticket),
            "max_output_tokens": 4000,  # includes reasoning tokens
            "store": False,
            "text": {"format": {"type": "json_schema", "name": "ticket_triage",
                                "schema": SCHEMA, "strict": True}},
        }
        if self.spec.effort:
            body["reasoning"] = {"effort": self.spec.effort}
        return body

    async def classify(self, ticket: dict) -> ClassificationResult:
        result = empty_result(self.key, ticket["id"], confidence_source="self_reported")
        start = time.perf_counter()
        try:
            for attempt in range(MAX_RETRIES + 1):
                resp = await self.client.post(self.url, json=self._payload(ticket))
                if resp.status_code in RETRY_STATUS and attempt < MAX_RETRIES:
                    result.retries += 1
                    await asyncio.sleep(0.5 * 2 ** attempt)
                    continue
                resp.raise_for_status()
                data = resp.json()
                parse_output(extract_text(data), result)
                usage = data.get("usage") or {}
                result.input_tokens = int(usage.get("input_tokens") or 0)
                result.output_tokens = int(usage.get("output_tokens") or 0)  # includes reasoning tokens
                result.model_version = data.get("model", "")
                break
        except httpx.HTTPStatusError as e:
            result.error = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        except Exception as e:
            result.error = f"{type(e).__name__}: {e}"[:300]
        result.latency_ms = (time.perf_counter() - start) * 1000
        result.cost_usd = (result.input_tokens * self.spec.input_price
                           + result.output_tokens * self.spec.output_price) / 1_000_000
        return result

    async def warmup(self) -> None:
        await self.classify({"id": "warmup", "channel": "chat", "plan": "basic", "subject": "Hello",
                             "message": "How do I reset my password?"})

    async def close(self) -> None:
        await self.client.aclose()
