"""Simulated classifier for rehearsals and offline demos (MOCK_MODE=true).

Numbers produced here are synthetic and NOT a result about any model. The UI shows a banner
whenever mock mode is on. All profiles share the same accuracy and are calibrated, so mock mode
never "pre-decides" the comparison; only latency differs, following each vendor's typical range.
"""
from __future__ import annotations

import asyncio
import hashlib
import os
import random

from ..config import ModelSpec
from ..taxonomy import FIELDS, LABELS
from .base import Classifier, ClassificationResult, empty_result

# median latency (ms), lognormal sigma, input tokens, output tokens
PROFILES = {
    "jev": (110, 0.35, 900, 5),
    "haiku": (900, 0.30, 1150, 110),
    "sonnet": (1800, 0.30, 1150, 110),
    "luna": (700, 0.30, 1100, 140),
    "sol": (1600, 0.30, 1100, 160),
}
BASE_ACCURACY = 0.86
AMBIGUOUS_PENALTY = 0.15
LATENCY_SCALE = float(os.getenv("MOCK_LATENCY_SCALE", "1.0"))  # tests use ~0


def _rng(model_key: str, ticket_id: str) -> random.Random:
    seed = int(hashlib.sha256(f"{model_key}:{ticket_id}".encode()).hexdigest()[:12], 16)
    return random.Random(seed)


def _wrong_label(rng: random.Random, field: str, gold: str) -> str:
    labels = LABELS[field]
    if field in ("level", "priority", "sentiment"):  # ordinal-ish: mistakes are usually adjacent
        i = labels.index(gold)
        near = [labels[j] for j in (i - 1, i + 1) if 0 <= j < len(labels)]
        return rng.choice(near)
    return rng.choice([lab for lab in labels if lab != gold])


class MockClassifier(Classifier):
    def __init__(self, spec: ModelSpec):
        self.key = spec.key
        self.spec = spec
        self.median, self.sigma, self.in_tok, self.out_tok = PROFILES.get(spec.key, PROFILES["haiku"])
        self.calibrated = spec.provider == "jev"

    async def classify(self, ticket: dict) -> ClassificationResult:
        rng = _rng(self.key, ticket["id"])
        result = empty_result(self.key, ticket["id"],
                              confidence_source="calibrated" if self.calibrated else "self_reported")
        gold = ticket.get("gold", {})
        ambiguous = ticket.get("difficulty") == "ambiguous"
        for f in FIELDS:
            p_correct = BASE_ACCURACY - (AMBIGUOUS_PENALTY if ambiguous and f in ("level", "priority") else 0)
            # Calibrated: the reported confidence equals the chance of being right.
            conf = min(0.99, max(0.30, rng.gauss(p_correct, 0.12)))
            correct = rng.random() < conf
            label = gold.get(f) if correct else _wrong_label(rng, f, gold.get(f))
            if label is None:
                label = rng.choice(LABELS[f])
            if not self.calibrated:
                conf = round(conf * 20) / 20  # LLMs tend to report round numbers
            result.labels[f] = label
            result.confidence[f] = round(conf, 3)
            if self.calibrated:
                others = [lab for lab in LABELS[f] if lab != label]
                weights = [rng.random() for _ in others]
                total = sum(weights) or 1
                probs = {lab: (1 - conf) * w / total for lab, w in zip(others, weights)}
                probs[label] = conf
                result.probabilities[f] = {k: round(v, 4) for k, v in probs.items()}
        latency = rng.lognormvariate(0, self.sigma) * self.median
        await asyncio.sleep(latency * LATENCY_SCALE / 1000)
        result.latency_ms = latency
        result.input_tokens, result.output_tokens = self.in_tok, self.out_tok
        result.cost_usd = (self.in_tok * self.spec.input_price + self.out_tok * self.spec.output_price) / 1e6
        result.model_version = f"mock:{self.spec.model_id}"
        return result
