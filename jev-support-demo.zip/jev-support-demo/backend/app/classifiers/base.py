from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Optional

from ..taxonomy import FIELDS, LABELS


@dataclass
class ClassificationResult:
    model_key: str
    ticket_id: str
    labels: dict[str, Optional[str]] = field(default_factory=dict)
    # Probability that the chosen label is right. JEV: calibrated. Claude: self-reported.
    confidence: dict[str, Optional[float]] = field(default_factory=dict)
    # Full distribution per field when the model returns one (JEV only).
    probabilities: dict[str, dict[str, float]] = field(default_factory=dict)
    latency_ms: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    model_version: str = ""
    retries: int = 0
    error: Optional[str] = None          # request failed entirely
    invalid_fields: list[str] = field(default_factory=list)  # answered with a label outside the taxonomy
    confidence_source: str = "calibrated"  # "calibrated" | "self_reported"
    timestamp: float = field(default_factory=time.time)

    @property
    def ok(self) -> bool:
        return self.error is None

    def to_dict(self) -> dict:
        return asdict(self)


def normalize_label(field_name: str, value) -> Optional[str]:
    """Map a raw answer to an allowed label, case-insensitively. None if it isn't one."""
    if not isinstance(value, str):
        return None
    wanted = value.strip().lower()
    return next((lab for lab in LABELS[field_name] if lab.lower() == wanted), None)


def clamp01(x) -> Optional[float]:
    try:
        return max(0.0, min(1.0, float(x)))
    except (TypeError, ValueError):
        return None


def empty_result(model_key: str, ticket_id: str, **kwargs) -> ClassificationResult:
    r = ClassificationResult(model_key=model_key, ticket_id=ticket_id, **kwargs)
    for f in FIELDS:
        r.labels.setdefault(f, None)
        r.confidence.setdefault(f, None)
    return r


class Classifier:
    """Interface every model implements."""

    key: str

    async def classify(self, ticket: dict) -> ClassificationResult:  # pragma: no cover
        raise NotImplementedError

    async def warmup(self) -> None:
        """Open connections before the timed run so the first ticket doesn't pay for the TLS handshake."""

    async def close(self) -> None:
        pass
