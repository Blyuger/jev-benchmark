"""JEV (TypeSafe System One) classifier over raw HTTP.

One request answers all 5 questions for a ticket (one "state", five "choice" questions).
Docs: POST {base}/v1/systemone, Authorization: Bearer <TYPESAFE_API_KEY>.
"""
from __future__ import annotations

import asyncio
import time

import httpx

from ..config import ModelSpec, Settings
from ..taxonomy import FIELDS, QUESTIONS, ticket_state
from .base import Classifier, ClassificationResult, clamp01, empty_result, normalize_label

RETRY_STATUS = {429, 503, 529}
MAX_RETRIES = 3


def build_questions() -> dict:
    return {
        f: {"type": "choice", "instructions": instructions, "criteria": criteria}
        for f, (instructions, criteria) in QUESTIONS.items()
    }


def parse_response(data: dict, result: ClassificationResult) -> None:
    answers = data.get("answers") or {}
    for f in FIELDS:
        ans = answers.get(f) or {}
        label = normalize_label(f, ans.get("choice"))
        probs = {k: clamp01(v) for k, v in (ans.get("probabilities") or {}).items()}
        probs = {k: v for k, v in probs.items() if v is not None}
        conf = clamp01(ans.get("confidence"))
        if conf is None and label and label in probs:
            conf = probs[label]
        result.labels[f] = label
        result.confidence[f] = conf
        if probs:
            result.probabilities[f] = probs
        if label is None:
            result.invalid_fields.append(f)
    usage = data.get("usage") or {}
    result.input_tokens = int(usage.get("input_tokens") or 0)
    result.output_tokens = int(usage.get("output_tokens") or 0)
    result.model_version = data.get("model", "")


class JevClassifier(Classifier):
    def __init__(self, spec: ModelSpec, settings: Settings):
        self.key = spec.key
        self.spec = spec
        self.url = settings.jev_base_url.rstrip("/") + "/v1/systemone"
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_s,
            headers={"Authorization": f"Bearer {settings.typesafe_api_key}",
                     "Content-Type": "application/json"},
        )
        self.questions = build_questions()

    def _payload(self, ticket: dict) -> dict:
        return {"model": self.spec.model_id, "state": ticket_state(ticket), "questions": self.questions}

    async def classify(self, ticket: dict) -> ClassificationResult:
        result = empty_result(self.key, ticket["id"], confidence_source="calibrated")
        start = time.perf_counter()
        try:
            for attempt in range(MAX_RETRIES + 1):
                resp = await self.client.post(self.url, json=self._payload(ticket))
                if resp.status_code in RETRY_STATUS and attempt < MAX_RETRIES:
                    result.retries += 1
                    await asyncio.sleep(0.5 * 2 ** attempt)
                    continue
                resp.raise_for_status()
                parse_response(resp.json(), result)
                break
        except httpx.HTTPStatusError as e:
            result.error = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        except Exception as e:  # network, timeout, malformed JSON
            result.error = f"{type(e).__name__}: {e}"[:300]
        result.latency_ms = (time.perf_counter() - start) * 1000
        result.cost_usd = (result.input_tokens * self.spec.input_price
                           + result.output_tokens * self.spec.output_price) / 1_000_000
        return result

    async def warmup(self) -> None:
        dummy = {"id": "warmup", "channel": "chat", "plan": "basic", "subject": "Hello",
                 "message": "How do I reset my password?"}
        await self.classify(dummy)

    async def close(self) -> None:
        await self.client.aclose()
