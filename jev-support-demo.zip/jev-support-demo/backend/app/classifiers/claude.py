"""Claude classifier using structured outputs (JSON schema with enums).

Same labels and definitions as JEV (both come from taxonomy.py). Claude also reports a confidence
per field, which is self-reported text rather than a calibrated probability; the comparison tab
shows how well each kind of confidence matches reality.

Latency setting: `output_config.effort = "low"` on models that support it (Sonnet 5.5).
Haiku 4.5 has no effort parameter; without extended thinking it already runs at its fastest.
"""
from __future__ import annotations

import time

from anthropic import APIStatusError, AsyncAnthropic

from ..config import ModelSpec, Settings
from ..taxonomy import ticket_state
from .base import Classifier, ClassificationResult, empty_result
from .llm_prompt import SCHEMA, SYSTEM_PROMPT, build_schema, build_system_prompt, parse_output  # noqa: F401


class ClaudeClassifier(Classifier):
    def __init__(self, spec: ModelSpec, settings: Settings):
        self.key = spec.key
        self.spec = spec
        self.client = AsyncAnthropic(api_key=settings.anthropic_api_key, max_retries=3,
                                     timeout=settings.request_timeout_s)
        self.output_config = {"format": {"type": "json_schema", "schema": SCHEMA}}
        if spec.effort:
            self.output_config["effort"] = spec.effort

    async def classify(self, ticket: dict) -> ClassificationResult:
        result = empty_result(self.key, ticket["id"], confidence_source="self_reported")
        start = time.perf_counter()
        try:
            msg = await self.client.messages.create(
                model=self.spec.model_id,
                max_tokens=1024,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": ticket_state(ticket)}],
                # Passed via extra_body so it works across SDK versions.
                extra_body={"output_config": self.output_config},
            )
            text = next((b.text for b in msg.content if b.type == "text"), "")
            parse_output(text, result)
            result.input_tokens = msg.usage.input_tokens
            result.output_tokens = msg.usage.output_tokens
            result.model_version = msg.model
        except APIStatusError as e:
            result.error = f"HTTP {e.status_code}: {str(e.message)[:200]}"
        except Exception as e:
            result.error = f"{type(e).__name__}: {e}"[:300]
        result.latency_ms = (time.perf_counter() - start) * 1000
        result.cost_usd = (result.input_tokens * self.spec.input_price
                           + result.output_tokens * self.spec.output_price) / 1_000_000
        return result

    async def warmup(self) -> None:
        await self.classify({"id": "warmup", "channel": "chat", "plan": "basic", "subject": "Hello",
                             "message": "How do I reset my password?"})

    async def close(self) -> None:
        await self.client.close()
