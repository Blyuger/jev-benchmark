"""Prompt, JSON schema and answer parsing shared by every generative model (Claude and GPT).

Built from taxonomy.py, so the LLMs see exactly the same labels and definitions as JEV.
"""
from __future__ import annotations

import json

from ..taxonomy import COMPANY_CONTEXT, FIELDS, LABELS, QUESTIONS
from .base import ClassificationResult, clamp01, normalize_label


def build_system_prompt() -> str:
    parts = [
        "You are a support-ticket triage classifier.",
        COMPANY_CONTEXT,
        "Answer the 5 questions below independently. For each one, pick exactly one label and give your "
        "confidence: the probability (0 to 1) that your label is correct.",
    ]
    for f, (instructions, criteria) in QUESTIONS.items():
        parts.append(f"\n## {f}\n{instructions}")
        parts.extend(f"- {label}: {desc}" for label, desc in criteria.items())
    return "\n".join(parts)


def build_schema() -> dict:
    return {
        "type": "object",
        "properties": {
            f: {
                "type": "object",
                "properties": {
                    "label": {"type": "string", "enum": LABELS[f]},
                    "confidence": {"type": "number"},
                },
                "required": ["label", "confidence"],
                "additionalProperties": False,
            }
            for f in FIELDS
        },
        "required": FIELDS,
        "additionalProperties": False,
    }


def parse_output(text: str, result: ClassificationResult) -> None:
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        result.invalid_fields = list(FIELDS)
        return
    for f in FIELDS:
        ans = data.get(f) or {}
        label = normalize_label(f, ans.get("label"))
        result.labels[f] = label
        result.confidence[f] = clamp01(ans.get("confidence"))
        if label is None:
            result.invalid_fields.append(f)


SYSTEM_PROMPT = build_system_prompt()
SCHEMA = build_schema()
