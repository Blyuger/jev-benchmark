"""FastAPI entry point: REST controls + a WebSocket that streams live events.

Run:  uvicorn app.main:app --reload --port 8000   (from the backend/ folder)
If frontend/dist exists (after `npm run build`), the UI is served at http://localhost:8000 too.
"""
from __future__ import annotations

from typing import Literal, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .config import PROJECT_DIR, settings
from .runner import RunManager

app = FastAPI(title="JEV Support Triage Demo")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
manager = RunManager(settings)


class RunRequest(BaseModel):
    mode: Literal["pipeline", "comparison"] = "pipeline"
    speed: float = Field(1.0, ge=0)   # 0 = as fast as possible
    shuffle: bool = True
    limit: Optional[int] = Field(None, ge=1)
    seed: int = 7


class SpeedRequest(BaseModel):
    speed: float = Field(..., ge=0)


class ThresholdRequest(BaseModel):
    value: float = Field(..., ge=0, le=1)


@app.get("/api/config")
def get_config():
    return {**manager.config(), "threshold": manager.threshold}


@app.get("/api/state")
def get_state():
    return manager.state()


@app.get("/api/tickets")
def get_tickets():
    return manager.tickets


@app.post("/api/run")
async def run(req: RunRequest):
    try:
        await manager.start(req.mode, req.speed, req.shuffle, req.limit, req.seed)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.post("/api/pause")
async def pause():
    await manager.pause()
    return {"ok": True}


@app.post("/api/resume")
async def resume():
    await manager.resume()
    return {"ok": True}


@app.post("/api/stop")
async def stop():
    await manager.stop()
    return {"ok": True}


@app.post("/api/speed")
async def speed(req: SpeedRequest):
    await manager.set_speed(req.speed)
    return {"ok": True}


@app.post("/api/threshold")
async def threshold(req: ThresholdRequest):
    await manager.set_threshold(req.value)
    return {"ok": True}


@app.get("/api/export")
def export():
    return manager.export()


@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()  # keep-alive; controls go through REST
    except WebSocketDisconnect:
        manager.disconnect(websocket)


dist = PROJECT_DIR / "frontend" / "dist"
if dist.exists():
    app.mount("/", StaticFiles(directory=dist, html=True), name="ui")
