"""Replays the ticket dataset through the models and streams events to every connected browser.

Modes:
  pipeline   -> JEV only (the production-style flow)
  comparison -> every model in settings.comparison_models runs as its OWN independent process:
                each one works through the same tickets back to back, at its own speed, with its
                own clock. The audience sees each model's current ticket and timer side by side,
                so a faster model simply finishes earlier.
"""
from __future__ import annotations

import asyncio
import json
import random
import time
from typing import Optional

from fastapi import WebSocket

from .classifiers import build_classifier
from .config import Settings
from .metrics import ModelMetrics, comparison

PIPELINE_GAP_S = 1.5    # pause between tickets at 1x (pipeline: time to read each decision)
COMPARISON_GAP_S = 0.5  # pause between tickets at 1x (race: same for every model)
RECENT = 6              # answers kept per lane for the on-screen log


def load_tickets(settings: Settings) -> list[dict]:
    return json.loads(settings.tickets_path.read_text(encoding="utf-8"))


class RunManager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.tickets = load_tickets(settings)
        self.clients: set[WebSocket] = set()
        self.threshold = settings.confidence_threshold
        self.status = "idle"   # idle | warming_up | running | paused | finished | stopped | error
        self.mode = "pipeline"
        self.speed = 1.0
        self.order: list[dict] = []
        self.position = 0
        self.metrics: dict[str, ModelMetrics] = {}
        self.lanes: dict[str, dict] = {}
        self.feed: list[dict] = []
        self.current: Optional[dict] = None
        self.message = ""
        self._task: Optional[asyncio.Task] = None
        self._resume = asyncio.Event()
        self._resume.set()
        # Run clock that stops while paused
        self._clock_start: Optional[float] = None
        self._paused_total = 0.0
        self._paused_since: Optional[float] = None
        self._finish_order = 0

    @property
    def modes(self) -> dict[str, list[str]]:
        return {"pipeline": ["jev"], "comparison": list(self.settings.comparison_models)}

    # ---------- clock ----------
    def elapsed_ms(self) -> float:
        if self._clock_start is None:
            return 0.0
        now = time.perf_counter()
        paused = self._paused_total + (now - self._paused_since if self._paused_since else 0)
        return (now - self._clock_start - paused) * 1000

    # ---------- broadcasting ----------
    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self.clients.add(ws)
        await ws.send_json({"type": "state", "data": self.state()})

    def disconnect(self, ws: WebSocket) -> None:
        self.clients.discard(ws)

    async def broadcast(self, event: dict) -> None:
        dead = []
        for ws in list(self.clients):
            try:
                await ws.send_json(event)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.clients.discard(ws)

    # ---------- state ----------
    def config(self) -> dict:
        return {
            "mock_mode": self.settings.mock_mode,
            "missing_keys": self.settings.missing_keys(),
            "ticket_count": len(self.tickets),
            "models": [{"key": m.key, "name": m.name, "provider": m.provider, "model_id": m.model_id,
                        "effort": m.effort, "setting_note": m.setting_note}
                       for m in self.settings.models],
            "modes": self.modes,
        }

    def lane_view(self, key: str) -> dict:
        lane = self.lanes[key]
        return {**lane, "elapsed_ms": self.elapsed_ms(), "running": self.status == "running"}

    def state(self) -> dict:
        return {
            "config": self.config(), "status": self.status, "mode": self.mode, "speed": self.speed,
            "threshold": self.threshold, "position": self.position, "total": len(self.order),
            "message": self.message, "current": self.current, "feed": self._feed(),
            "metrics": {k: m.snapshot(self.threshold) for k, m in self.metrics.items()},
            "comparison": comparison(self.metrics) if len(self.metrics) > 1 else None,
            "lanes": {k: self.lane_view(k) for k in self.lanes},
        }

    async def push_status(self) -> None:
        await self.broadcast({"type": "status", "data": {
            "status": self.status, "mode": self.mode, "speed": self.speed, "threshold": self.threshold,
            "position": self.position, "total": len(self.order), "message": self.message,
            "elapsed_ms": self.elapsed_ms()}})

    async def push_lane(self, key: str) -> None:
        await self.broadcast({"type": "lane", "data": self.lane_view(key)})

    # ---------- controls ----------
    async def start(self, mode: str, speed: float, shuffle: bool, limit: Optional[int], seed: int) -> None:
        if mode not in self.modes:
            raise ValueError(f"Unknown mode {mode}")
        missing = self.settings.missing_keys(self.modes[mode])
        if missing:
            raise ValueError(f"Missing API keys: {', '.join(missing)} (or set MOCK_MODE=true)")
        await self.stop(silent=True)
        self.mode, self.speed = mode, speed
        self.order = list(self.tickets)
        if shuffle:
            random.Random(seed).shuffle(self.order)
        if limit:
            self.order = self.order[:limit]
        self.position = 0
        self.feed, self.current, self.message = [], None, ""
        self.metrics, self.lanes = {}, {}
        self._clock_start, self._paused_total, self._paused_since = None, 0.0, None
        self._finish_order = 0
        for key in self.modes[mode]:
            spec = self.settings.model(key)
            source = "calibrated" if spec.provider == "jev" else "self_reported"
            self.metrics[key] = ModelMetrics(key, spec.name, source)
            self.lanes[key] = {
                "key": key, "name": spec.name, "setting_note": spec.setting_note,
                "position": 0, "total": len(self.order), "state": "waiting",
                "ticket": None, "request_started_ms": None, "last_latency_ms": None,
                "busy_ms": 0.0, "finished_ms": None, "rank": None, "recent": [],
                "correct_level": 0, "done": 0,
            }
        self._resume.set()
        await self.broadcast({"type": "state", "data": self.state()})
        self._task = asyncio.create_task(self._run())

    async def pause(self) -> None:
        if self.status == "running":
            self._resume.clear()
            self._paused_since = time.perf_counter()
            self.status = "paused"
            await self.push_status()

    async def resume(self) -> None:
        if self.status == "paused":
            if self._paused_since:
                self._paused_total += time.perf_counter() - self._paused_since
                self._paused_since = None
            self._resume.set()
            self.status = "running"
            await self.push_status()

    async def stop(self, silent: bool = False) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self.status = "stopped"
            if not silent:
                await self.push_status()
        self._resume.set()
        self._paused_since = None

    async def set_speed(self, speed: float) -> None:
        self.speed = speed
        await self.push_status()

    async def set_threshold(self, value: float) -> None:
        self.threshold = max(0.0, min(1.0, value))
        await self.broadcast({"type": "state", "data": self.state()})

    # ---------- the run ----------
    async def _run(self) -> None:
        classifiers = {k: build_classifier(k, self.settings) for k in self.metrics}
        try:
            self.status, self.message = "warming_up", "Opening connections (warm-up calls are not measured)"
            await self.push_status()
            await asyncio.gather(*(c.warmup() for c in classifiers.values()), return_exceptions=True)
            self.status, self.message = "running", ""
            self._clock_start = time.perf_counter()
            await self.broadcast({"type": "state", "data": self.state()})
            # One independent process per model, all started at the same instant.
            await asyncio.gather(*(self._worker(k, c) for k, c in classifiers.items()))
            self.status, self.message = "finished", f"Processed {len(self.order)} tickets"
            await self.push_status()
            await self.broadcast({"type": "state", "data": self.state()})
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self.status, self.message = "error", f"{type(e).__name__}: {e}"
            await self.push_status()
        finally:
            for c in classifiers.values():
                try:
                    await c.close()
                except Exception:
                    pass

    async def _worker(self, key: str, clf) -> None:
        lane = self.lanes[key]
        gap = PIPELINE_GAP_S if self.mode == "pipeline" else COMPARISON_GAP_S
        for i, ticket in enumerate(self.order):
            await self._resume.wait()
            lane.update(position=i + 1, state="working", ticket=ticket,
                        request_started_ms=self.elapsed_ms())
            if self.mode == "pipeline":
                self.position = i + 1
                self.current = {"ticket": ticket, "results": {}, "started_at": time.time()}
                await self.broadcast({"type": "ticket", "data": {
                    "position": self.position, "total": len(self.order), "ticket": ticket}})
            else:
                self.position = max(self.position, i + 1)
            await self.push_lane(key)

            result = await clf.classify(ticket)
            payload = await self._handle_result(result, ticket)

            lane["busy_ms"] += result.latency_ms
            lane["last_latency_ms"] = result.latency_ms
            lane["done"] = i + 1
            lane["correct_level"] += int(payload["correct"]["level"])
            lane["recent"] = [{
                "ticket_id": ticket["id"], "subject": ticket["subject"],
                "level": result.labels.get("level"), "gold_level": ticket["gold"]["level"],
                "correct": payload["correct"]["level"],
                "latency_ms": result.latency_ms, "error": result.error,
            }, *lane["recent"]][:RECENT]
            lane["state"] = "answered"
            await self.push_lane(key)
            if len(self.metrics) > 1:
                await self.broadcast({"type": "comparison", "data": comparison(self.metrics)})
            if self.speed > 0 and i < len(self.order) - 1:
                await asyncio.sleep(gap / self.speed)

        self._finish_order += 1
        lane.update(state="finished", finished_ms=self.elapsed_ms(), rank=self._finish_order,
                    request_started_ms=None)
        await self.push_lane(key)

    def _payload(self, key: str, rec, result_dict: dict) -> dict:
        return {
            "model_key": key, "ticket_id": rec.ticket_id, "result": result_dict,
            "routing": self.metrics[key].routing_for(rec, self.threshold),
            "correct": rec.correct, "gold": rec.gold, "difficulty": rec.difficulty,
        }

    def _feed(self) -> list[dict]:
        """JEV feed rebuilt with the current threshold, so routing reflects the slider."""
        m = self.metrics.get("jev")
        if not m:
            return []
        results = {(i["model_key"], i["ticket_id"]): i["result"] for i in self.feed}
        return [self._payload("jev", r, results.get(("jev", r.ticket_id), {})) for r in m.records]

    async def _handle_result(self, result, ticket: dict) -> dict:
        m = self.metrics[result.model_key]
        rec = m.add(result, ticket)
        payload = self._payload(result.model_key, rec, result.to_dict())
        if self.current and self.current["ticket"]["id"] == ticket["id"]:
            self.current["results"][result.model_key] = payload
        self.feed.append(payload)
        await self.broadcast({"type": "result", "data": payload})
        await self.broadcast({"type": "metrics", "data": m.snapshot(self.threshold)})
        return payload

    def export(self) -> dict:
        return {"mode": self.mode, "threshold": self.threshold,
                "metrics": {k: m.snapshot(self.threshold) for k, m in self.metrics.items()},
                "records": {k: [r.__dict__ for r in m.records] for k, m in self.metrics.items()},
                "lanes": {k: self.lane_view(k) for k in self.lanes},
                "comparison": comparison(self.metrics) if len(self.metrics) > 1 else None}
