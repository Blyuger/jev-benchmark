"""Evaluation metrics. Everything is exact match against the gold labels (no LLM-as-a-judge).

Each ticket has exactly one gold label per question (ambiguous tickets were adjudicated to one label).
An answer is right only if it equals that label; there is no partial or "acceptable alternative" credit.

Snapshots are recomputed from the stored records on every event (at most a few hundred records),
which keeps the code simple and lets the confidence threshold change live.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .router import gold_route, route, routing_outcome
from .taxonomy import FIELDS, LEVEL_ORDER

CAL_BINS = 10
COVERAGE_STEPS = [round(i * 0.05, 2) for i in range(21)]


@dataclass
class Record:
    ticket_id: str
    labels: dict[str, Optional[str]]
    confidence: dict[str, Optional[float]]
    gold: dict[str, str]
    latency_ms: float
    cost_usd: float
    input_tokens: int
    output_tokens: int
    error: Optional[str]
    invalid_fields: list[str]
    retries: int
    difficulty: str
    correct: dict[str, bool] = field(init=False)

    def __post_init__(self):
        self.correct = {f: self.labels.get(f) == self.gold[f] for f in FIELDS}

    @property
    def all_correct(self) -> bool:
        return all(self.correct.values())


def percentile(values: list[float], p: float) -> Optional[float]:
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * p / 100
    lo, hi = math.floor(k), math.ceil(k)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def _ratio(n: int, d: int) -> Optional[float]:
    return n / d if d else None


def calibration(points: list[tuple[float, bool]]) -> dict:
    """Reliability bins, Expected Calibration Error and top-label Brier score."""
    bins = []
    n = len(points)
    ece = 0.0
    for b in range(CAL_BINS):
        lo, hi = b / CAL_BINS, (b + 1) / CAL_BINS
        inside = [(c, ok) for c, ok in points if (lo <= c < hi) or (b == CAL_BINS - 1 and c == 1.0)]
        if inside:
            mean_conf = sum(c for c, _ in inside) / len(inside)
            acc = sum(ok for _, ok in inside) / len(inside)
            ece += len(inside) / n * abs(acc - mean_conf)
        else:
            mean_conf = acc = None
        bins.append({"lo": lo, "hi": hi, "count": len(inside), "mean_confidence": mean_conf, "accuracy": acc})
    brier = sum((c - ok) ** 2 for c, ok in points) / n if n else None
    return {"bins": bins, "ece": ece if n else None, "brier": brier, "points": n}


class ModelMetrics:
    def __init__(self, key: str, name: str, confidence_source: str):
        self.key = key
        self.name = name
        self.confidence_source = confidence_source
        self.records: list[Record] = []
        self.model_version = ""

    def add(self, result, ticket: dict) -> Record:
        rec = Record(
            ticket_id=ticket["id"], labels=dict(result.labels), confidence=dict(result.confidence),
            gold=ticket["gold"],
            latency_ms=result.latency_ms, cost_usd=result.cost_usd,
            input_tokens=result.input_tokens, output_tokens=result.output_tokens,
            error=result.error, invalid_fields=list(result.invalid_fields), retries=result.retries,
            difficulty=ticket.get("difficulty", "clear"),
        )
        self.records.append(rec)
        if result.model_version:
            self.model_version = result.model_version
        return rec

    def routing_for(self, rec: Record, threshold: float) -> dict:
        decision = route(rec.labels, rec.confidence, threshold)
        expected = gold_route(rec.gold)
        return {**decision, "expected_queue": expected["queue"],
                "outcome": routing_outcome(decision["queue"], expected["queue"])}

    def snapshot(self, threshold: float) -> dict:
        recs = self.records
        n = len(recs)
        ok = [r for r in recs if r.error is None]
        lat = [r.latency_ms for r in ok]

        accuracy = {
            "by_field": {f: _ratio(sum(r.correct[f] for r in recs), n) for f in FIELDS},
            # "Exact match ratio": the ticket counts only if all 5 labels match the answer key.
            "all_fields": _ratio(sum(r.all_correct for r in recs), n),
            "all_fields_count": sum(r.all_correct for r in recs),
        }

        # Accuracy for clear vs borderline tickets and per support level, as counts and rates (level question + all 5 labels)
        def bucket(rs: list[Record]) -> dict:
            t = len(rs)
            out = {"total": t}
            for name, n_ok in (
                ("level", sum(r.correct["level"] for r in rs)),
                ("all_fields", sum(r.all_correct for r in rs)),
            ):
                out[name] = {"correct": n_ok, "rate": _ratio(n_ok, t)}
            return out

        by_difficulty = {d: bucket([r for r in recs if r.difficulty == d]) for d in ("clear", "ambiguous")}
        by_level = {lab: bucket([r for r in recs if r.gold["level"] == lab]) for lab in LEVEL_ORDER}

        # Level: confusion matrix (rows = gold, cols = predicted; last col = no valid answer)
        idx = {lab: i for i, lab in enumerate(LEVEL_ORDER)}
        confusion = [[0] * (len(LEVEL_ORDER) + 1) for _ in LEVEL_ORDER]
        under = over = severe_under = 0
        for r in recs:
            g, p = r.gold["level"], r.labels.get("level")
            confusion[idx[g]][idx[p] if p in idx else len(LEVEL_ORDER)] += 1
            if p in idx:
                diff = idx[p] - idx[g]
                under += diff < 0
                over += diff > 0
                severe_under += diff <= -2
        per_class = {}
        for lab in LEVEL_ORDER:
            tp = sum(r.labels.get("level") == lab and r.gold["level"] == lab for r in recs)
            pred = sum(r.labels.get("level") == lab for r in recs)
            support = sum(r.gold["level"] == lab for r in recs)
            per_class[lab] = {"precision": _ratio(tp, pred), "recall": _ratio(tp, support), "support": support}

        # Calibration: every (field, ticket) decision with a confidence is one point.
        all_points = [(r.confidence[f], r.correct[f]) for r in recs for f in FIELDS
                      if r.confidence.get(f) is not None]
        level_points = [(r.confidence["level"], r.correct["level"]) for r in recs
                        if r.confidence.get("level") is not None]
        conf_hist = [0] * CAL_BINS
        for c, _ in all_points:
            conf_hist[min(int(c * CAL_BINS), CAL_BINS - 1)] += 1

        # Sure vs unsure: level answers split by the model's own confidence at the routing threshold.
        # "Sure" answers are the ones the router automates; a wrong sure answer is a confident mistake.
        def split(rs: list[Record]) -> dict:
            right = sum(r.correct["level"] for r in rs)
            return {"total": len(rs), "right": right, "wrong": len(rs) - right,
                    "accuracy": _ratio(right, len(rs))}

        answered = [r for r in recs if r.labels.get("level") is not None and r.confidence.get("level") is not None]
        sure = [r for r in answered if r.confidence["level"] >= threshold]
        unsure = [r for r in answered if r.confidence["level"] < threshold]
        confidence_split = {"threshold": threshold, "sure": split(sure), "unsure": split(unsure),
                            "no_answer": n - len(answered)}

        # Coverage: if only decisions with level confidence >= t were automated
        coverage = []
        for t in COVERAGE_STEPS:
            kept = [r for r in recs if (r.confidence.get("level") or 0) >= t and r.labels.get("level")]
            coverage.append({"threshold": t, "coverage": _ratio(len(kept), n),
                             "accuracy": _ratio(sum(r.correct["level"] for r in kept), len(kept))})

        # Routing at the current threshold
        routes = [self.routing_for(r, threshold) for r in recs]
        kinds, queues, outcomes = {}, {}, {"correct": 0, "safe": 0, "unsafe": 0}
        for d in routes:
            kinds[d["kind"]] = kinds.get(d["kind"], 0) + 1
            queues[d["queue"]] = queues.get(d["queue"], 0) + 1
            outcomes[d["outcome"]] += 1
        contained = kinds.get("auto_resolved", 0)

        # Risk detection: of the tickets that really carry risk, how many did the model flag?
        risky = [r for r in recs if r.gold["risk"] != "none"]
        caught = sum(r.labels.get("risk") not in (None, "none") for r in risky)

        total_cost = sum(r.cost_usd for r in recs)
        cum, cost_series = 0.0, []
        for i, r in enumerate(recs):
            cum += r.cost_usd
            cost_series.append({"i": i + 1, "ticket_id": r.ticket_id, "cum_usd": cum})
        return {
            "key": self.key, "name": self.name, "confidence_source": self.confidence_source,
            "model_version": self.model_version,
            "processed": n, "errors": sum(r.error is not None for r in recs),
            "invalid_outputs": sum(bool(r.invalid_fields) for r in recs),
            "retries": sum(r.retries for r in recs),
            "level_correct": sum(r.correct["level"] for r in recs),
            "level_wrong": n - sum(r.correct["level"] for r in recs),
            "accuracy": accuracy,
            "by_difficulty": by_difficulty,
            "by_level": by_level,
            "level": {"labels": LEVEL_ORDER, "confusion": confusion, "under_escalation": under,
                      "over_escalation": over, "severe_under_escalation": severe_under,
                      "per_class": per_class},
            "risk_detection": {"risky": len(risky), "caught": caught, "missed": len(risky) - caught},
            "latency": {
                "last": lat[-1] if lat else None, "mean": sum(lat) / len(lat) if lat else None,
                "p50": percentile(lat, 50), "p95": percentile(lat, 95), "p99": percentile(lat, 99),
                "min": min(lat) if lat else None, "max": max(lat) if lat else None,
                "series": [{"i": i + 1, "ticket_id": r.ticket_id, "ms": round(r.latency_ms, 1)}
                           for i, r in enumerate(recs) if r.error is None],
                # Sequential throughput this model alone could sustain
                "throughput_per_s": 1000 / (sum(lat) / len(lat)) if lat else None,
            },
            "calibration": {"all": calibration(all_points), "level": calibration(level_points),
                            "confidence_histogram": conf_hist},
            "confidence_split": confidence_split,
            "coverage": coverage,
            "routing": {"threshold": threshold, "kinds": kinds, "queues": queues, "outcomes": outcomes,
                        "containment_rate": _ratio(contained, n),
                        "human_overrides": kinds.get("risk_override", 0) + kinds.get("sentiment_override", 0),
                        "page_on_call": sum(d["page_on_call"] for d in routes)},
            "cost": {"total_usd": total_cost, "per_ticket_usd": _ratio(total_cost, n) if n else None,
                     "per_1k_tickets_usd": total_cost / n * 1000 if n else None,
                     "series": cost_series,
                     "input_tokens": sum(r.input_tokens for r in recs),
                     "output_tokens": sum(r.output_tokens for r in recs)},
        }


def comparison(metrics: dict[str, ModelMetrics]) -> dict:
    """Cross-model view: pairwise level agreement and the tickets where models disagree."""
    by_ticket: dict[str, dict[str, Record]] = {}
    for key, m in metrics.items():
        for r in m.records:
            by_ticket.setdefault(r.ticket_id, {})[key] = r
    keys = list(metrics)
    complete = {t: rs for t, rs in by_ticket.items() if len(rs) == len(keys)}
    agreement = {}
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            same = sum(rs[a].labels.get("level") == rs[b].labels.get("level") for rs in complete.values())
            agreement[f"{a}|{b}"] = _ratio(same, len(complete))
    disagreements = []
    for t, rs in complete.items():
        levels = {k: rs[k].labels.get("level") for k in keys}
        if len(set(levels.values())) > 1:
            any_rec = next(iter(rs.values()))
            disagreements.append({
                "ticket_id": t, "gold": any_rec.gold["level"], "difficulty": any_rec.difficulty,
                "answers": {k: {"level": levels[k], "confidence": rs[k].confidence.get("level"),
                                "correct": rs[k].correct["level"]} for k in keys},
            })
    all_agree = sum(len({rs[k].labels.get("level") for k in keys}) == 1 for rs in complete.values())
    return {"compared": len(complete), "all_agree_rate": _ratio(all_agree, len(complete)),
            "pairwise_agreement": agreement, "disagreements": disagreements[-30:][::-1]}
