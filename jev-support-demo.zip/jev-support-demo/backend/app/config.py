"""Settings loaded from environment variables (or a .env file in backend/)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent
load_dotenv(BACKEND_DIR / ".env")


def _float(name: str, default: float) -> float:
    return float(os.getenv(name, default))


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


def _opt(name: str, default: Optional[str]) -> Optional[str]:
    value = os.getenv(name, default if default is not None else "")
    return value.strip() or None


@dataclass
class ModelSpec:
    key: str             # internal id used by the frontend
    name: str            # display name
    provider: str        # "jev" | "anthropic" | "openai"
    model_id: str
    input_price: float   # USD per million input tokens
    output_price: float  # USD per million output tokens
    # Reasoning effort sent to the API ("low" for latency). None = the model has no such parameter.
    effort: Optional[str] = None
    # Shown in the UI so the audience knows how each model was configured.
    setting_note: str = ""


API_KEY_ENV = {"jev": "TYPESAFE_API_KEY", "anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY"}


def _default_models() -> list[ModelSpec]:
    sonnet_effort = _opt("SONNET_EFFORT", "low")
    luna_effort = _opt("LUNA_EFFORT", "low")
    sol_effort = _opt("SOL_EFFORT", "low")
    return [
        ModelSpec("jev", "JEV", "jev", os.getenv("JEV_MODEL", "jev-1.13.0"),
                  _float("JEV_INPUT_PRICE", 0.042), _float("JEV_OUTPUT_PRICE", 0.0),
                  None, "Single pass, no reasoning setting"),
        ModelSpec("haiku", "Claude Haiku 4.5", "anthropic",
                  os.getenv("HAIKU_MODEL", "claude-haiku-4-5-20251001"),
                  _float("HAIKU_INPUT_PRICE", 1.0), _float("HAIKU_OUTPUT_PRICE", 5.0),
                  None, "Thinking off (Haiku has no effort setting)"),
        ModelSpec("sonnet", "Claude Sonnet 5.5", "anthropic",
                  os.getenv("SONNET_MODEL", "claude-sonnet-5-5"),
                  _float("SONNET_INPUT_PRICE", 2.0), _float("SONNET_OUTPUT_PRICE", 10.0),
                  sonnet_effort, f"Effort: {sonnet_effort or 'default'}"),
        ModelSpec("luna", "GPT-6 Luna", "openai", os.getenv("LUNA_MODEL", "gpt-6-luna"),
                  _float("LUNA_INPUT_PRICE", 0.10), _float("LUNA_OUTPUT_PRICE", 0.50),
                  luna_effort, f"Reasoning effort: {luna_effort or 'default'}"),
        ModelSpec("sol", "GPT-6.1 Sol", "openai", os.getenv("SOL_MODEL", "gpt-6.1-sol"),
                  _float("SOL_INPUT_PRICE", 2.0), _float("SOL_OUTPUT_PRICE", 10.0),
                  sol_effort, f"Reasoning effort: {sol_effort or 'default'}"),
    ]


@dataclass
class Settings:
    typesafe_api_key: str = field(default_factory=lambda: os.getenv("TYPESAFE_API_KEY", ""))
    anthropic_api_key: str = field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))
    openai_api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    jev_base_url: str = field(default_factory=lambda: os.getenv("JEV_BASE_URL", "https://api.typesafe.ai"))
    openai_base_url: str = field(default_factory=lambda: os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    # When true, no API is called: results are simulated (clearly flagged in the UI).
    mock_mode: bool = field(default_factory=lambda: _bool("MOCK_MODE", False))
    confidence_threshold: float = field(default_factory=lambda: _float("CONFIDENCE_THRESHOLD", 0.75))
    request_timeout_s: float = field(default_factory=lambda: _float("REQUEST_TIMEOUT_S", 30))
    tickets_path: Path = field(default_factory=lambda: Path(
        os.getenv("TICKETS_PATH", PROJECT_DIR / "data" / "tickets.json")))
    models: list[ModelSpec] = field(default_factory=_default_models)
    # Which models race in the Comparison tab (drop any you have no key for).
    comparison_models: list[str] = field(default_factory=lambda: [
        k.strip() for k in os.getenv("COMPARISON_MODELS", "jev,haiku,sonnet,luna,sol").split(",") if k.strip()])

    def model(self, key: str) -> ModelSpec:
        return next(m for m in self.models if m.key == key)

    def key_for(self, provider: str) -> str:
        return {"jev": self.typesafe_api_key, "anthropic": self.anthropic_api_key,
                "openai": self.openai_api_key}[provider]

    def missing_keys(self, model_keys: Optional[list[str]] = None) -> list[str]:
        if self.mock_mode:
            return []
        keys = model_keys or ["jev", *self.comparison_models]
        providers = {self.model(k).provider for k in keys}
        return sorted(API_KEY_ENV[p] for p in providers if not self.key_for(p))


settings = Settings()
